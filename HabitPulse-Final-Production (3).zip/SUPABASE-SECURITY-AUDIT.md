# HabitPulse — مراجعة أمان Supabase وRLS

**تاريخ المراجعة:** 2026-10-15  
**النطاق:** `supabase/schema.sql`، طبقة البيانات `lib/habits-remote.ts`، مسارات الخادم الخاصة بالحساب وStripe وAI Coach.

> هذه مراجعة للكود ومخطط SQL الموجودين في المشروع. لم يتم تنفيذ أي تعديل على مشروع Supabase البعيد، لأن ذلك يتطلب تشغيل SQL في لوحة Supabase أو اتصالًا إداريًا مباشرًا.

## الخلاصة

- **حالة RLS العامة:** مفعّلة على الجداول الخمسة، وسياسات العادات والسجلات والمراجعات تقصر الصفوف على `auth.uid()`.
- **حماية مفاتيح الخدمة:** جيدة؛ مفتاح `SUPABASE_SERVICE_ROLE_KEY` مستخدم في مسارات الخادم فقط، وليس في مكونات العميل.
- **النتيجة:** لا أوصي باعتبار المخطط الحالي نهائيًا للإنتاج قبل معالجة النقاط عالية/متوسطة الأولوية أدناه.

## النتائج

### 1. عالية الأولوية — سجل العادة يمكن ربطه نظريًا بعادة مستخدم آخر

السياسة الحالية على `habit_logs` تتحقق من أن `user_id = auth.uid()` فقط:

```sql
using (auth.uid() = user_id)
with check (auth.uid() = user_id)
```

لكنها لا تتحقق من أن `habit_id` يشير إلى عادة يملكها المستخدم نفسه. وبما أن المفتاح الأجنبي الحالي يربط `habit_id` بالعادة فقط، يمكن لمستخدم مصادق عليه يعرف معرّف عادة أخرى أن يحاول إدخال سجل بهذه العادة مع `user_id` الخاص به.

**التوصية:** إضافة قيد أجنبي مركّب `(habit_id, user_id)` إلى `habits(id, user_id)`، مع الإبقاء على سياسة RLS كطبقة حماية ثانية.

### 2. عالية الأولوية — نفس المشكلة في `weekly_reflections`

عمود `weekly_reflections.habit_id` يشير إلى العادة دون ربط `user_id` بمالك العادة. هذا يسمح نظريًا بإنشاء ملاحظة مرتبطة بعادة لا يملكها المستخدم.

**التوصية:** استخدام القيد الأجنبي المركّب نفسه. بالنسبة للمراجعة الأسبوعية العامة، يبقى `habit_id` مساويًا لـ `NULL`.

### 3. متوسطة — سياسة `profiles_select_own` تكشف أعمدة Stripe للمستخدم

السياسة تقصر الصف على الملف الشخصي الحالي، وهذا جيد، لكنها لا تمنع قراءة كل الأعمدة في ذلك الصف. لذلك يمكن لأي مستخدم مصادق عليه تنفيذ `select * from profiles` وقراءة:

- `stripe_customer_id`
- `stripe_subscription_id`

هذه ليست مفاتيح سرية، لكنها بيانات داخلية لا يحتاجها العميل، ولا ينبغي كشفها عبر Data API.

**التوصية:** استخدام صلاحيات أعمدة صريحة ومنح العميل فقط الأعمدة اللازمة مثل `id`, `is_pro`, `subscription_status`, `pro_since`, و`updated_at`. يبقى مفتاح الخدمة قادرًا على قراءة كل الأعمدة لمسارات webhook والحساب.

### 4. متوسطة — خطأ مخطط/تطبيق في `full_name`

`components/settings/account-section.tsx` ينفذ:

```ts
supabase.from('profiles').update({ full_name: trimmed })
```

لكن جدول `profiles` في `schema.sql` لا يحتوي عمود `full_name`، كما لا توجد سياسة `UPDATE` للملف الشخصي. النتيجة المتوقعة أن تحديث الاسم في هذا القسم يفشل أو لا يكتمل.

**التوصية:** اختيار أحد المسارين:

- حفظ الاسم في `auth.users.user_metadata` فقط وحذف تحديث `profiles`، أو
- إضافة `full_name` إلى `profiles` مع سياسة تحديث آمنة تسمح للمستخدم بتحديث `full_name` فقط، وليس حقول Pro أو Stripe.

المسار الثاني يحتاج صلاحيات أعمدة صريحة حتى لا يتمكن العميل من تعديل `is_pro` أو بيانات Stripe.

### 5. متوسطة — `weekly_reflections` لا تضمن التفرد للمراجعات العامة

القيد الحالي:

```sql
unique (user_id, habit_id, week_start)
```

لا يمنع تكرار الصفوف عندما يكون `habit_id` مساويًا لـ `NULL`، لأن PostgreSQL يعامل قيم `NULL` كغير متساوية في القيود الفريدة. وهذا يؤثر على `upsert` الخاص بالمراجعة الأسبوعية العامة.

**التوصية:** إضافة unique index جزئي للمراجعات العامة، وآخر للمراجعات المرتبطة بعادة:

```sql
create unique index if not exists weekly_reflections_global_uidx
  on public.weekly_reflections (user_id, week_start)
  where habit_id is null;

create unique index if not exists weekly_reflections_habit_uidx
  on public.weekly_reflections (user_id, habit_id, week_start)
  where habit_id is not null;
```

ينبغي أيضًا تحديث كود الحفظ ليستخدم مسار upsert منفصلًا للمراجعة العامة والمرتبطة بعادة، لأن `onConflict` مع الفهارس الجزئية يحتاج تحديدًا مناسبًا.

### 6. منخفضة — تحسين صريح لصلاحيات `stripe_events`

المخطط يلغي الصلاحيات لـ `anon` و`authenticated`، ولا توجد سياسة RLS، وهذا يمنع وصول المتصفح عمليًا. للتحصين ضد تغيّر الصلاحيات الافتراضية، يفضّل أيضًا الإلغاء صراحة من `public` وعدم منح أي صلاحيات للعميل.

### 7. منخفضة — قيود صحة البيانات

يفضل إضافة قيود للحد من البيانات غير الصحيحة حتى عند تجاوز واجهة التطبيق، مثل:

- طول اسم العادة بين 1 و120 حرفًا.
- `target_time` قيمة وقت صحيحة أو `NULL`.
- `content` بطول معقول للملاحظات.
- `subscription_status` ضمن مجموعة قيم معروفة، إن كانت دورة Stripe تعتمد عليها.

## ما هو جيد حاليًا

- RLS مفعّلة على `profiles`, `habits`, `habit_logs`, `weekly_reflections`, و`stripe_events`.
- سياسات العادات والمراجعات تستخدم `auth.uid()` بدل الاعتماد على قيمة يرسلها العميل وحدها.
- حذف المستخدم من مسار الخادم يتحقق من Bearer token قبل استخدام Admin API.
- Stripe webhook يتحقق من `stripe-signature` قبل تعديل حالة Pro.
- `stripe_events` يستخدم معرف الحدث لمنع التكرار.
- دالة إنشاء الملف الشخصي تستخدم `security definer` مع `search_path = public`، وهي ممارسة صحيحة لتقليل مخاطر search path injection.
- لا يتم إرسال مفتاح الخدمة إلى العميل حسب مسارات الكود التي تمت مراجعتها.

## SQL تصحيحي مقترح

> طبّق هذا بعد أخذ نسخة احتياطية، وراجع أسماء القيود الفعلية في قاعدة البيانات إذا كان المخطط قد شُغّل سابقًا.

```sql
-- 1) Unique key يسمح بإنشاء foreign keys مركبة على ملكية العادة.
create unique index if not exists habits_id_user_id_uidx
  on public.habits (id, user_id);

-- 2) اربط سجلات العادة بمالك العادة نفسه.
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'habit_logs_habit_user_fkey'
      and conrelid = 'public.habit_logs'::regclass
  ) then
    alter table public.habit_logs
      add constraint habit_logs_habit_user_fkey
      foreign key (habit_id, user_id)
      references public.habits (id, user_id)
      on delete cascade;
  end if;
end $$;

-- 3) اربط الملاحظات المرتبطة بعادة بمالك العادة.
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'weekly_reflections_habit_user_fkey'
      and conrelid = 'public.weekly_reflections'::regclass
  ) then
    alter table public.weekly_reflections
      add constraint weekly_reflections_habit_user_fkey
      foreign key (habit_id, user_id)
      references public.habits (id, user_id)
      on delete cascade;
  end if;
end $$;

-- 4) منع تكرار المراجعة العامة أو المرتبطة بعادة.
create unique index if not exists weekly_reflections_global_uidx
  on public.weekly_reflections (user_id, week_start)
  where habit_id is null;

create unique index if not exists weekly_reflections_habit_uidx
  on public.weekly_reflections (user_id, habit_id, week_start)
  where habit_id is not null;

-- 5) حماية جدول أحداث Stripe صراحة.
revoke all on table public.stripe_events from public, anon, authenticated;

-- 6) قيود أساسية على المدخلات.
alter table public.habits
  drop constraint if exists habits_name_length_check;
alter table public.habits
  add constraint habits_name_length_check
  check (char_length(btrim(name)) between 1 and 120);

alter table public.weekly_reflections
  drop constraint if exists weekly_reflections_content_length_check;
alter table public.weekly_reflections
  add constraint weekly_reflections_content_length_check
  check (char_length(content) <= 10000);
```

## قرار `full_name`

إذا كان المطلوب دعم تعديل الاسم من صفحة الإعدادات، أضف أولًا:

```sql
alter table public.profiles add column if not exists full_name text;
```

ثم لا تستخدم سياسة `update ... for all`. الأفضل منح صلاحية العمود المحدد فقط، بعد التأكد من دعم صلاحيات الأعمدة في مشروعك:

```sql
grant update (full_name) on table public.profiles to authenticated;

drop policy if exists "profiles_update_name" on public.profiles;
create policy "profiles_update_name"
on public.profiles
for update
using (auth.uid() = id)
with check (auth.uid() = id);
```

ويجب اختبار أن العميل لا يستطيع تعديل `is_pro` أو `stripe_customer_id` أو `stripe_subscription_id`. إذا أردت أقوى عزل، انقل تحديث الاسم إلى Edge Function/مسار خادم يتحقق من الحقول المسموح بها، واترك جدول `profiles` غير قابل للتحديث من العميل.

## اختبارات تحقق مقترحة بعد التطبيق

1. مستخدم A لا يستطيع `select`, `update`, `delete` أي عادة لمستخدم B.
2. مستخدم A لا يستطيع إدخال `habit_logs` باستخدام `habit_id` لمستخدم B.
3. مستخدم A لا يستطيع إدخال reflection مرتبطة بعادة مستخدم B.
4. `select * from profiles` من جلسة العميل لا يعيد أعمدة Stripe الحساسة.
5. مستخدم عادي لا يستطيع تعديل `profiles.is_pro`.
6. لا يستطيع `anon` القراءة أو الإدراج أو التعديل في `stripe_events`.
7. webhook الموقّع فقط يستطيع تحديث حالة Pro عبر Admin API.
8. حذف المستخدم يحذف العادات والسجلات والمراجعات عبر `on delete cascade`.

## الحكم النهائي

**RLS الحالية بداية جيدة لكنها تحتاج hardening قبل اعتمادها كإعداد إنتاج نهائي.** أهم إجراءين هما إضافة ربط ملكية مركب لسجلات العادات والمراجعات، وتقييد أعمدة `profiles` التي يمكن قراءتها من العميل. كما يجب معالجة عدم تطابق `full_name` بين الواجهة والمخطط.
