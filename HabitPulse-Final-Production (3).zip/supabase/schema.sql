-- HabitPulse Supabase schema
-- Run this once in Supabase Dashboard → SQL Editor before using cloud persistence.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  is_pro boolean not null default false,
  subscription_status text not null default 'free',
  stripe_customer_id text,
  stripe_subscription_id text,
  pro_since timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists public.habits (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  target_time time,
  created_at timestamptz not null default now(),
  archived boolean not null default false
);

create index if not exists habits_user_id_created_at_idx
  on public.habits(user_id, created_at);

create table if not exists public.habit_logs (
  user_id uuid not null references auth.users(id) on delete cascade,
  habit_id text not null references public.habits(id) on delete cascade,
  log_date date not null,
  created_at timestamptz not null default now(),
  primary key (habit_id, log_date)
);

create index if not exists habit_logs_user_id_date_idx
  on public.habit_logs(user_id, log_date);

create table if not exists public.weekly_reflections (
  user_id uuid not null references auth.users(id) on delete cascade,
  habit_id text references public.habits(id) on delete cascade,
  week_start date not null,
  content text not null default '',
  updated_at timestamptz not null default now(),
  unique (user_id, habit_id, week_start)
);

create table if not exists public.stripe_events (
  id text primary key,
  type text not null,
  received_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id) values (new.id)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.habits enable row level security;
alter table public.habit_logs enable row level security;
alter table public.weekly_reflections enable row level security;
alter table public.stripe_events enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);

drop policy if exists "habits_own" on public.habits;
create policy "habits_own" on public.habits for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "habit_logs_own" on public.habit_logs;
create policy "habit_logs_own" on public.habit_logs for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "weekly_reflections_own" on public.weekly_reflections;
create policy "weekly_reflections_own" on public.weekly_reflections for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Stripe events are server-only; no browser policy is created.
revoke all on public.stripe_events from anon, authenticated;
