/** @type {import('next').NextConfig} */
const supabaseOrigin = process.env.NEXT_PUBLIC_SUPABASE_URL ?? ''

const securityHeaders = [
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'Strict-Transport-Security', value: 'max-age=63072000' },
  { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
  {
    key: 'Content-Security-Policy-Report-Only',
    value: [
      "default-src 'self'",
      "img-src 'self' data: blob: https:",
      "style-src 'self' 'unsafe-inline'",
      `connect-src 'self' ${supabaseOrigin} ${supabaseOrigin.replace(/^https/, 'wss')} https://api.stripe.com https://vitals.vercel-insights.com`.trim(),
      "frame-ancestors 'self'",
    ].join('; '),
  },
]

const nextConfig = {
  // The sandbox preview proxies browser requests from this host in development.
  // Allowing it prevents Next.js from blocking client chunks and HMR resources.
  allowedDevOrigins: ['3000-idfnrwk8qkkakl33dxi5g-033c4cb2.sg2.manus.computer'],
  images: {
    unoptimized: true,
  },
  async headers() {
    return [{ source: '/:path*', headers: securityHeaders }]
  },
}

export default nextConfig
