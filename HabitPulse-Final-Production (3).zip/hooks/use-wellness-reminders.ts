'use client'

import { useCallback, useSyncExternalStore } from 'react'

const STORAGE_KEY = 'habitpulse:wellness-reminders:v1'

export type WellnessReminderKey = 'hydration' | 'digitalDetox' | 'mindfulness'

export interface WellnessReminderPreferences {
  hydration: boolean
  digitalDetox: boolean
  mindfulness: boolean
}

const DEFAULTS: WellnessReminderPreferences = {
  hydration: false,
  digitalDetox: false,
  mindfulness: false,
}

const listeners = new Set<() => void>()
let cache: WellnessReminderPreferences | null = null

function emit() {
  listeners.forEach((listener) => listener())
}

function subscribe(listener: () => void) {
  listeners.add(listener)
  window.addEventListener('storage', listener)
  return () => {
    listeners.delete(listener)
    window.removeEventListener('storage', listener)
  }
}

function read(): WellnessReminderPreferences {
  if (cache) return cache
  try {
    const parsed = JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? 'null') as Partial<WellnessReminderPreferences> | null
    cache = {
      hydration: parsed?.hydration === true,
      digitalDetox: parsed?.digitalDetox === true,
      mindfulness: parsed?.mindfulness === true,
    }
  } catch {
    cache = { ...DEFAULTS }
  }
  return cache
}

function getServerSnapshot() {
  return DEFAULTS
}

function write(next: WellnessReminderPreferences) {
  cache = next
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
  } catch {
    // Preferences remain available in memory when storage is unavailable.
  }
  emit()
}

export function useWellnessReminders() {
  const preferences = useSyncExternalStore(subscribe, read, getServerSnapshot)
  const setReminder = useCallback((key: WellnessReminderKey, enabled: boolean) => {
    write({ ...read(), [key]: enabled })
  }, [])

  return { preferences, setReminder }
}
