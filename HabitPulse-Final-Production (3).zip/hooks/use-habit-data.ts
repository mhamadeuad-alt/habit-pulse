'use client'

import { useCallback, useRef } from 'react'
import useSWR from 'swr'
import { toast } from 'sonner'
import type { SupabaseClient, User } from '@supabase/supabase-js'
import {
  createId,
  withHabit,
  withNote,
  withoutHabit,
  withReflection,
  type Habit,
  type HabitState,
} from '@/lib/habits'
import {
  deleteHabit,
  fetchRemoteState,
  insertHabit,
  saveReflection,
  setHabitLog,
  type RemoteState,
} from '@/lib/habits-remote'

export type DataMode = 'unavailable' | 'cloud'

export function useHabitData(supabase: SupabaseClient | null, user: User | null) {
  const userId = user?.id ?? ''
  const cloudKey = supabase && user ? (['habitpulse', user.id] as const) : null

  /**
   * Cloud writes are serialized through one promise chain so that
   *  - they reach Supabase in the order the user made them (e.g. add habit -> check it),
   *  - a fetch never runs while writes are in flight (it would return stale rows and
   *    wipe optimistic state).
   */
  const queueRef = useRef<Promise<unknown>>(Promise.resolve())
  const pendingRef = useRef(0)
  /** Bumped on every local write so a fetch can tell whether its result is already outdated. */
  const writeSeqRef = useRef(0)

  const { data: remote, mutate, error } = useSWR<RemoteState>(cloudKey, async () => {
    for (;;) {
      const seq = writeSeqRef.current
      let queue: Promise<unknown>
      do {
        queue = queueRef.current
        await queue
      } while (queue !== queueRef.current)
      const fresh = await fetchRemoteState(supabase!, user!.id)
      // A write started (or finished) while we were fetching: this snapshot may miss it.
      if (seq === writeSeqRef.current && pendingRef.current === 0) return fresh
    }
  })

  /**
   * Always-current copy of the cloud state. It is updated synchronously on every
   * action, so two clicks in the same tick compose instead of each starting from
   * the (stale) snapshot captured by the render that created the handler.
   */
  const latestRef = useRef<RemoteState | null>(null)
  const latestOwnerRef = useRef<string>('')
  if (latestOwnerRef.current !== userId) {
    latestOwnerRef.current = userId
    latestRef.current = null
  }
  if (pendingRef.current === 0) latestRef.current = remote ?? null

  const mode: DataMode = cloudKey ? 'cloud' : 'unavailable'
  const state: HabitState | null = mode === 'cloud' ? (remote ?? null) : null
  const isPro = mode === 'cloud' ? Boolean(remote?.isPro) : false

  const applyCloud = useCallback(
    (transition: (s: HabitState) => HabitState, sync: () => Promise<void>) => {
      const current = latestRef.current
      if (!current) return
      // 1. Update the UI immediately, from the latest known state.
      const next: RemoteState = { ...current, ...transition(current) }
      latestRef.current = next
      void mutate(next, { revalidate: false })

      // 2. Persist in order. On failure, re-sync from the server (after the queue drains).
      pendingRef.current += 1
      writeSeqRef.current += 1
      const task = queueRef.current.then(sync)
      queueRef.current = task.then(
        () => undefined,
        () => undefined,
      )
      task.then(
        () => {
          pendingRef.current -= 1
          writeSeqRef.current += 1
        },
        () => {
          pendingRef.current -= 1
          writeSeqRef.current += 1
          toast.error('Could not sync with Supabase. Your change was reverted.')
          // The fetcher waits for the queue to drain, so this restores server truth
          // while keeping every other write that succeeded.
          void mutate()
        },
      )
    },
    [mutate],
  )

  function apply(transition: (s: HabitState) => HabitState, sync: () => Promise<void>) {
    if (mode !== 'cloud') return
    applyCloud(transition, sync)
  }

  return {
    mode,
    state,
    isPro,
    error: mode === 'cloud' ? error : undefined,
    refresh: () => mutate(),
    addHabit(name: string, targetTime: string) {
      const habit: Habit = { id: createId(), name: name.trim(), targetTime, createdAt: new Date().toISOString() }
      apply((s) => withHabit(s, habit), () => insertHabit(supabase!, userId, habit))
    },
    removeHabit(habitId: string) {
      apply((s) => withoutHabit(s, habitId), () => deleteHabit(supabase!, userId, habitId))
    },
    toggleCompletion(habitId: string, iso: string) {
      if (mode !== 'cloud') return
      // Decide check vs. uncheck from the *latest* state, not the rendered one.
      const latest = latestRef.current
      if (!latest) return
      const done = !latest.completions[habitId]?.[iso]
      applyCloud(
        (s) => setCell(s, habitId, iso, done),
        () => setHabitLog(supabase!, userId, habitId, iso, done),
      )
    },
    setNote(weekKey: string, habitId: string, text: string) {
      apply((s) => withNote(s, weekKey, habitId, text), () => saveReflection(supabase!, userId, weekKey, habitId, text))
    },
    setReflection(weekKey: string, text: string) {
      apply((s) => withReflection(s, weekKey, text), () => saveReflection(supabase!, userId, weekKey, null, text))
    },
  }
}

/** Idempotent set (not toggle): the optimistic state matches exactly what is written remotely. */
function setCell(state: HabitState, habitId: string, iso: string, done: boolean): HabitState {
  const days = { ...(state.completions[habitId] ?? {}) }
  if (done) days[iso] = true
  else delete days[iso]
  return { ...state, completions: { ...state.completions, [habitId]: days } }
}

export type HabitData = ReturnType<typeof useHabitData>
