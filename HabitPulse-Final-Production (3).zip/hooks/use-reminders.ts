'use client'

import { useCallback, useEffect, useState, useSyncExternalStore } from 'react'
import { toast } from 'sonner'
import { formatTargetTime, getStreak, toISODate, type HabitState } from '@/lib/habits'
import { useLocale } from '@/lib/i18n'

const PREF_KEY = 'habitpulse:reminders:v1'
const IN_APP_KEY = 'habitpulse:reminders:in-app:v1'
const NUDGE_KEY = 'habitpulse:streak-nudge:v1'
const listeners = new Set<() => void>()

export type NotificationSupport = 'unsupported' | NotificationPermission
export type ReminderMode = 'system' | 'in-app' | 'off'

function emit() {
  listeners.forEach((l) => l())
}

function subscribe(listener: () => void) {
  listeners.add(listener)
  window.addEventListener('storage', listener)

  // Browsers don't fire an event on Notification.permission, but the Permissions API does when
  // the user flips the site setting (address-bar lock icon). Keeps the UI honest without a reload.
  let status: PermissionStatus | null = null
  let cancelled = false
  try {
    void navigator.permissions
      ?.query({ name: 'notifications' })
      .then((s) => {
        if (cancelled) return
        status = s
        s.addEventListener('change', listener)
      })
      .catch(() => {})
  } catch {
    // Permissions API unavailable (older Safari); recheck() covers it.
  }

  return () => {
    cancelled = true
    listeners.delete(listener)
    window.removeEventListener('storage', listener)
    status?.removeEventListener('change', listener)
  }
}

function readFlag(key: string): boolean {
  try {
    return window.localStorage.getItem(key) === 'on'
  } catch {
    return false
  }
}

function writeFlag(key: string, value: boolean) {
  try {
    window.localStorage.setItem(key, value ? 'on' : 'off')
  } catch {
    // Storage unavailable; preference lasts for this session only.
  }
  emit()
}

function readPermission(): NotificationSupport {
  return typeof Notification === 'undefined' ? 'unsupported' : Notification.permission
}

/** Notification prompts are silently denied inside cross-origin iframes (e.g. preview panes). */
function readEmbedded(): boolean {
  try {
    return window.self !== window.top
  } catch {
    return true
  }
}

function msUntilNextMidnight(now: Date) {
  const next = new Date(now)
  next.setHours(24, 0, 5, 0)
  return next.getTime() - now.getTime()
}

/**
 * Reminder preferences + browser permission state. Safe to use on any page; it does not
 * need habit data. Preferences live in this browser because notification permission is per-browser.
 */
export function useReminderSettings() {
  const { isArabic } = useLocale()
  const enabled = useSyncExternalStore(subscribe, () => readFlag(PREF_KEY), () => false)
  const inApp = useSyncExternalStore(subscribe, () => readFlag(IN_APP_KEY), () => false)
  const permission = useSyncExternalStore(subscribe, readPermission, () => 'default' as NotificationSupport)
  const embedded = useSyncExternalStore(subscribe, readEmbedded, () => false)

  const mode: ReminderMode = !enabled ? 'off' : permission === 'granted' ? 'system' : inApp ? 'in-app' : 'off'
  const blocked = permission === 'denied' || permission === 'unsupported'

  /** Re-read the browser permission, e.g. after the user changed it in site settings. */
  const recheck = useCallback(() => {
    emit()
    return readPermission()
  }, [])

  const setEnabled = useCallback(async (next: boolean): Promise<NotificationSupport | 'off'> => {
    if (!next) {
      writeFlag(PREF_KEY, false)
      toast('Reminders turned off')
      return 'off'
    }

    let result = readPermission()
    if (result === 'unsupported') {
      toast.error('This browser does not support notifications.', {
        description: 'You can still get in-app reminders while HabitPulse is open.',
      })
      return result
    }

    if (result === 'default') {
      // Must run inside the click handler that called us (user gesture).
      try {
        result = await Notification.requestPermission()
      } catch {
        result = 'denied'
      }
      emit()
    }

    if (result !== 'granted') {
      toast.error(result === 'denied' ? 'Notifications are blocked' : 'Notification permission was dismissed', {
        description:
          result === 'denied'
            ? 'Allow notifications for this site in your browser settings, or use in-app reminders.'
            : 'Choose “Allow” when your browser asks, or use in-app reminders instead.',
      })
      return result
    }

    writeFlag(PREF_KEY, true)
    toast.success('Daily reminders on', {
      description: 'You will be nudged at each habit’s target time while HabitPulse is open.',
    })
    return result
  }, [])

  /** In-app fallback: reminders appear as toasts inside the open app, no browser permission needed. */
  const setInApp = useCallback((next: boolean) => {
    writeFlag(IN_APP_KEY, next)
    if (next) writeFlag(PREF_KEY, true)
  }, [])

  const sendNudge = useCallback((title: string, body: string, tag: string) => {
    if (readPermission() === 'granted') {
      try {
        new Notification(title, {
          body,
          tag,
          icon: '/icon.svg',
        })
        return
      } catch {
        // Some mobile browsers only allow notifications via a service worker; fall through.
      }
    }
    toast(title, { description: body })
  }, [])

  const sendTest = useCallback(() => {
    sendNudge('HabitPulse test reminder', 'Notifications are working. Keep your streak alive.', 'habitpulse-test')
  }, [sendNudge])

  const sendNudgePreview = useCallback(() => {
    sendNudge(
      isArabic ? 'استمراريتك ذات العشرة أيام في خطر!' : 'Your 10-day streak is in danger!',
      isArabic ? 'إنجاز صغير واحد يبقي الشعلة مشتعلة. أنت قادر على ذلك.' : 'One tiny win keeps the flame alive. You’ve got this.',
      'habitpulse-nudge-preview',
    )
  }, [isArabic, sendNudge])

  return {
    enabled,
    inApp,
    permission,
    embedded,
    blocked,
    mode,
    /** True when reminders will actually be delivered somehow. */
    active: mode !== 'off',
    setEnabled,
    setInApp,
    recheck,
    sendTest,
    sendNudgePreview,
  }
}

/**
 * Schedules a reminder at each habit's target time today, skipping habits already checked off.
 * Uses system notifications when permitted, otherwise in-app toasts if the fallback is on.
 * Re-arms itself after midnight.
 */
export function useReminders(state: HabitState | null) {
  const settings = useReminderSettings()
  const { isArabic, t } = useLocale()
  const [dayTick, setDayTick] = useState(0)
  const { mode } = settings

  useEffect(() => {
    if (mode === 'off' || !state) return
    const now = new Date()
    const todayIso = toISODate(now)
    const incomplete = state.habits.filter((habit) => !state.completions[habit.id]?.[todayIso])
    if (incomplete.length > 0 && now.getHours() >= 18) {
      let sent = false
      try { sent = window.localStorage.getItem(NUDGE_KEY) === todayIso } catch {}
      if (!sent) {
        const bestStreak = Math.max(0, ...state.habits.map((habit) => getStreak(state.completions[habit.id], now)))
        const title = isArabic
          ? bestStreak >= 2 ? `استمراريتك ذات ${bestStreak} أيام في خطر!` : t('streakInDanger')
          : bestStreak >= 2 ? `Your ${bestStreak}-day streak is in danger!` : 'Your streak is in danger!'
        const body = isArabic
          ? `لديك ${incomplete.length} عادات تنتظر الإنجاز. إنجاز واحد يحافظ على الشعلة مشتعلة.`
          : `${incomplete.length} habit${incomplete.length === 1 ? '' : 's'} still waiting. One tiny win keeps the flame alive.`
        if (mode === 'system') { try { new Notification(title, { body, tag: `habitpulse-nudge-${todayIso}`, icon: '/icon.svg' }); sent = true } catch {} }
        if (!sent) { toast(title, { description: body }); sent = true }
        try { window.localStorage.setItem(NUDGE_KEY, todayIso) } catch {}
      }
    }
    const timers: ReturnType<typeof setTimeout>[] = []

    for (const habit of state.habits) {
      if (!habit.targetTime || state.completions[habit.id]?.[todayIso]) continue
      const [h, m] = habit.targetTime.split(':').map(Number)
      const fireAt = new Date(now)
      fireAt.setHours(h, m, 0, 0)
      const delay = fireAt.getTime() - now.getTime()
      if (delay <= 0) continue
      timers.push(
        setTimeout(() => {
          const streak = getStreak(state.completions[habit.id], now)
          const body = isArabic
            ? `موعدها ${formatTargetTime(habit.targetTime)}. ${streak > 0 ? `احمِ استمراريتك ذات ${streak} أيام!` : 'ابدأ شعلة جديدة اليوم.'}`
            : `Scheduled for ${formatTargetTime(habit.targetTime)}. ${streak > 0 ? `Protect your ${streak}-day streak!` : 'Start a fresh flame today.'}`
          if (mode === 'system') {
            try {
              new Notification(`Time for: ${habit.name}`, {
                body,
                tag: `habitpulse-${habit.id}-${todayIso}`,
                icon: '/icon.svg',
              })
              return
            } catch {
              // fall through to the in-app toast
            }
          }
          toast(`Time for: ${habit.name}`, { description: body })
        }, delay),
      )
    }

    timers.push(setTimeout(() => setDayTick((t) => t + 1), msUntilNextMidnight(now)))
    return () => timers.forEach(clearTimeout)
  }, [mode, state, dayTick, isArabic])

  return { enabled: settings.active, permission: settings.permission, setEnabled: settings.setEnabled }
}
