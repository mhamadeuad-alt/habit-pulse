import { HabitPulse } from '@/components/habitpulse/habit-pulse'

export default function Page() {
  return <HabitPulse />
}
