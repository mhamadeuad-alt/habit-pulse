import { Suspense } from 'react'
import { AuthCallback } from '@/components/habitpulse/auth-callback'

export const metadata = { title: 'Signing you in — HabitPulse' }

export default function Page() {
  return (
    <Suspense fallback={null}>
      <AuthCallback />
    </Suspense>
  )
}
