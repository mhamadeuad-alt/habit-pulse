import Stripe from 'stripe'
import { createClient } from '@supabase/supabase-js'

const PRO_UNIT_AMOUNT_CENTS = 399

export async function POST(request: Request) {
  const stripeKey = process.env.STRIPE_SECRET_KEY
  if (!stripeKey) {
    return Response.json({ error: 'Stripe is not configured.' }, { status: 503 })
  }

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseAnon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  const token = request.headers.get('authorization')?.replace(/^Bearer\s+/i, '')

  let userId: string | undefined
  let email: string | undefined
  if (supabaseUrl && supabaseAnon) {
    if (!token) return Response.json({ error: 'Sign in to upgrade.' }, { status: 401 })
    const supabase = createClient(supabaseUrl, supabaseAnon)
    const { data, error } = await supabase.auth.getUser(token)
    if (error || !data.user) return Response.json({ error: 'Invalid session.' }, { status: 401 })
    userId = data.user.id
    email = data.user.email ?? undefined
  }

  const idempotencyKey = request.headers.get('idempotency-key')
  const safeIdempotencyKey =
    idempotencyKey && /^[\w-]{8,64}$/.test(idempotencyKey) ? idempotencyKey : undefined

  const origin = request.headers.get('origin') ?? new URL(request.url).origin
  const stripe = new Stripe(stripeKey)

  try {
    const session = await stripe.checkout.sessions.create(
      {
        mode: 'subscription',
        line_items: [
          {
            quantity: 1,
            price_data: {
              currency: 'usd',
              unit_amount: PRO_UNIT_AMOUNT_CENTS,
              recurring: { interval: 'month' },
              product_data: {
                name: 'HabitPulse Pro',
                description: 'Unlimited habits, advanced insights, and cloud sync.',
              },
            },
          },
        ],
        customer_email: email,
        client_reference_id: userId,
        metadata: userId ? { user_id: userId } : undefined,
        subscription_data: userId ? { metadata: { user_id: userId } } : undefined,
        success_url: `${origin}/?upgrade=success`,
        cancel_url: `${origin}/?upgrade=cancelled`,
      },
      safeIdempotencyKey ? { idempotencyKey: safeIdempotencyKey } : undefined,
    )
    return Response.json({ mode: 'live' as const, url: session.url })
  } catch (error) {
    console.error('Stripe checkout failed', error)
    return Response.json({ error: 'Unable to start checkout.' }, { status: 500 })
  }
}
