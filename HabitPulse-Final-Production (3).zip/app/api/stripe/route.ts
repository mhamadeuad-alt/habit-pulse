import Stripe from 'stripe'
import type { SupabaseClient } from '@supabase/supabase-js'
import { getSupabaseAdminClient } from '@/lib/supabase'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const PRO_STATUSES: ReadonlySet<Stripe.Subscription.Status> = new Set(['active', 'trialing'])

type ProfilePatch = {
  is_pro: boolean
  subscription_status: string
  stripe_customer_id?: string | null
  stripe_subscription_id?: string | null
  pro_since?: string | null
  updated_at: string
}

function idOf(value: string | { id: string } | null | undefined): string | null {
  if (!value) return null
  return typeof value === 'string' ? value : value.id
}

async function updateProfile(
  admin: SupabaseClient,
  match: { userId?: string | null; customerId?: string | null },
  patch: ProfilePatch,
) {
  const query = admin.from('profiles').update(patch)
  const { error } = match.userId
    ? await query.eq('id', match.userId)
    : match.customerId
      ? await query.eq('stripe_customer_id', match.customerId)
      : { error: null }
  if (error) throw error
}

async function syncSubscription(admin: SupabaseClient, subscription: Stripe.Subscription) {
  const isPro = PRO_STATUSES.has(subscription.status)
  const ended = subscription.status === 'canceled' || subscription.status === 'incomplete_expired'
  await updateProfile(
    admin,
    { userId: subscription.metadata?.user_id, customerId: idOf(subscription.customer) },
    {
      is_pro: isPro,
      subscription_status: subscription.status,
      stripe_customer_id: idOf(subscription.customer),
      stripe_subscription_id: ended ? null : subscription.id,
      updated_at: new Date().toISOString(),
    },
  )
}

export async function POST(request: Request) {
  const stripeKey = process.env.STRIPE_SECRET_KEY
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET
  const admin = getSupabaseAdminClient()
  if (!stripeKey || !webhookSecret || !admin) {
    return Response.json({ error: 'Billing is not configured.' }, { status: 503 })
  }

  const signature = request.headers.get('stripe-signature')
  if (!signature) return Response.json({ error: 'Missing signature.' }, { status: 400 })

  const stripe = new Stripe(stripeKey)
  let event: Stripe.Event
  try {
    event = stripe.webhooks.constructEvent(await request.text(), signature, webhookSecret)
  } catch {
    return Response.json({ error: 'Invalid signature.' }, { status: 400 })
  }

  // Stripe retries deliveries; record each event id once to stay idempotent.
  const { error: dedupeError } = await admin
    .from('stripe_events')
    .insert({ id: event.id, type: event.type })
  if (dedupeError?.code === '23505') return Response.json({ received: true, duplicate: true })
  if (dedupeError) console.error('Could not record Stripe event', dedupeError)

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object
        if (session.mode !== 'subscription') break
        const userId = session.client_reference_id ?? session.metadata?.user_id
        if (!userId) break
        await updateProfile(
          admin,
          { userId },
          {
            is_pro: true,
            subscription_status: 'active',
            stripe_customer_id: idOf(session.customer),
            stripe_subscription_id: idOf(session.subscription),
            pro_since: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
        )
        break
      }
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted':
        await syncSubscription(admin, event.data.object)
        break
      default:
        break
    }
  } catch (error) {
    console.error(`Stripe webhook ${event.type} failed`, error)
    // Let Stripe retry: remove the dedupe marker so the next attempt is processed.
    await admin.from('stripe_events').delete().eq('id', event.id)
    return Response.json({ error: 'Webhook handler failed.' }, { status: 500 })
  }

  return Response.json({ received: true })
}
