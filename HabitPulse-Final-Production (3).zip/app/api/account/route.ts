import Stripe from 'stripe'
import { getSupabaseAdminClient } from '@/lib/supabase'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * Permanently deletes the signed-in user. Needs the service-role key because users cannot
 * delete themselves from the browser. Habits, logs, reflections and the profile row are
 * removed by ON DELETE CASCADE.
 */
export async function DELETE(request: Request) {
  const admin = getSupabaseAdminClient()
  if (!admin) {
    return Response.json({ error: 'Account deletion is not configured on this deployment.' }, { status: 503 })
  }

  const token = request.headers.get('authorization')?.replace(/^Bearer\s+/i, '')
  if (!token) return Response.json({ error: 'Sign in first.' }, { status: 401 })

  const { data, error } = await admin.auth.getUser(token)
  if (error || !data.user) return Response.json({ error: 'Invalid session.' }, { status: 401 })
  const userId = data.user.id

  // Stop billing first. If this fails we abort, so nobody is charged for an account that no longer exists.
  const stripeKey = process.env.STRIPE_SECRET_KEY
  if (stripeKey) {
    const { data: profile } = await admin
      .from('profiles')
      .select('stripe_subscription_id')
      .eq('id', userId)
      .maybeSingle()
    const subscriptionId = profile?.stripe_subscription_id as string | null | undefined
    if (subscriptionId) {
      try {
        await new Stripe(stripeKey).subscriptions.cancel(subscriptionId)
      } catch (err) {
        const code = (err as { code?: string }).code
        if (code !== 'resource_missing') {
          console.error('Could not cancel Stripe subscription before account deletion', err)
          return Response.json(
            { error: 'We could not cancel your subscription, so your account was not deleted. Please try again.' },
            { status: 502 },
          )
        }
      }
    }
  }

  const { error: deleteError } = await admin.auth.admin.deleteUser(userId)
  if (deleteError) {
    console.error('Account deletion failed', deleteError)
    return Response.json({ error: 'Could not delete your account. Please try again.' }, { status: 500 })
  }

  return Response.json({ deleted: true })
}
