import { createClient } from '@supabase/supabase-js'
import { getSupabaseAdminClient } from '@/lib/supabase'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

type CoachRequest = {
  habits?: Array<{ name: string; streak: number; completionRate: number }>
  completionRate?: number
  bestWeekday?: string | null
}

function promptFor(input: CoachRequest) {
  const habits = (input.habits ?? []).map((habit) => `${habit.name}: ${habit.completionRate}% completion, ${habit.streak}-day streak`).join('; ')
  return `You are HabitPulse Coach. Give one concise, practical coaching insight in 2 short sentences and one next action. Use a warm, premium tone. Current completion rate: ${input.completionRate ?? 0}%. Best weekday: ${input.bestWeekday ?? 'unknown'}. Habits: ${habits || 'none'}.`
}

async function askOpenAI(prompt: string) {
  const key = process.env.OPENAI_API_KEY
  if (!key) return null
  const base = (process.env.OPENAI_API_BASE || 'https://api.openai.com/v1').replace(/\/$/, '')
  const response = await fetch(`${base}/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
    body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', temperature: 0.4, max_tokens: 160, messages: [{ role: 'user', content: prompt }] }),
  })
  if (!response.ok) throw new Error(`OpenAI request failed: ${response.status}`)
  const json = (await response.json()) as { choices?: Array<{ message?: { content?: string } }> }
  return json.choices?.[0]?.message?.content?.trim() || null
}

async function askGemini(prompt: string) {
  const key = process.env.GEMINI_API_KEY
  if (!key) return null
  const model = process.env.GEMINI_MODEL || 'gemini-2.0-flash'
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.4, maxOutputTokens: 160 } }),
  })
  if (!response.ok) throw new Error(`Gemini request failed: ${response.status}`)
  const json = (await response.json()) as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> }
  return json.candidates?.[0]?.content?.parts?.map((part) => part.text ?? '').join('').trim() || null
}

export async function POST(request: Request) {
  const token = request.headers.get('authorization')?.replace(/^Bearer\s+/i, '')
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  const admin = getSupabaseAdminClient()

  if (!token || !url || !anon || !admin) return Response.json({ error: 'AI Coach requires a connected Pro account.' }, { status: 401 })

  const supabase = createClient(url, anon)
  const { data: userData, error: userError } = await supabase.auth.getUser(token)
  if (userError || !userData.user) return Response.json({ error: 'Invalid session.' }, { status: 401 })
  const { data: profile, error: profileError } = await admin.from('profiles').select('is_pro').eq('id', userData.user.id).maybeSingle()
  if (profileError || !profile?.is_pro) return Response.json({ error: 'AI Coach is available to Pro subscribers only.' }, { status: 403 })

  const input = (await request.json().catch(() => ({}))) as CoachRequest
  const prompt = promptFor(input)
  if (!process.env.OPENAI_API_KEY && !process.env.GEMINI_API_KEY) return Response.json({ error: 'Add OPENAI_API_KEY or GEMINI_API_KEY to enable AI Coach.' }, { status: 503 })
  try {
    const insight = (await askOpenAI(prompt)) ?? (await askGemini(prompt))
    if (!insight) return Response.json({ error: 'AI Coach returned no insight.' }, { status: 502 })
    return Response.json({ insight, provider: process.env.OPENAI_API_KEY ? 'openai' : 'gemini' })
  } catch (error) {
    console.error('AI Coach request failed', error)
    return Response.json({ error: 'AI Coach is temporarily unavailable.' }, { status: 502 })
  }
}
