import { Suspense } from 'react'
import type { Metadata } from 'next'
import { SettingsPage } from '@/components/settings/settings-page'

export const metadata: Metadata = {
  title: 'Settings — HabitPulse',
  description: 'Manage your HabitPulse account, preferences and reminders.',
}

export default function Page() {
  return (
    <Suspense fallback={null}>
      <SettingsPage />
    </Suspense>
  )
}
