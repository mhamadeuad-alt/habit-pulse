-- HabitPulse schema: profiles, habits, habit_logs, weekly_reflections
-- Requires Postgres 15+ (Supabase default) for UNIQUE NULLS NOT DISTINCT.

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- profiles: one row per auth user, holds subscription state
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text,
  full_name text,
  is_pro boolean not null default false,
  stripe_customer_id text unique,
  stripe_subscription_id text,
  pro_since timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- habits
-- ---------------------------------------------------------------------------
create table if not exists public.habits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  name text not null check (char_length(name) between 1 and 80),
  target_time time,
  archived boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists habits_user_id_idx on public.habits (user_id);

-- ---------------------------------------------------------------------------
-- habit_logs: one row per completed day
-- ---------------------------------------------------------------------------
create table if not exists public.habit_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  habit_id uuid not null references public.habits (id) on delete cascade,
  log_date date not null,
  created_at timestamptz not null default now(),
  unique (habit_id, log_date)
);
create index if not exists habit_logs_user_date_idx on public.habit_logs (user_id, log_date);

-- ---------------------------------------------------------------------------
-- weekly_reflections: habit_id = null is the overall weekly reflection,
-- otherwise it is a side note for that habit during that week.
-- week_start is the Saturday that starts the Sat -> Fri week.
-- ---------------------------------------------------------------------------
create table if not exists public.weekly_reflections (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  habit_id uuid references public.habits (id) on delete cascade,
  week_start date not null,
  content text not null default '' check (char_length(content) <= 4000),
  updated_at timestamptz not null default now(),
  constraint weekly_reflections_unique unique nulls not distinct (user_id, habit_id, week_start)
);

-- ---------------------------------------------------------------------------
-- Row Level Security
-- ---------------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.habits enable row level security;
alter table public.habit_logs enable row level security;
alter table public.weekly_reflections enable row level security;

-- profiles: users can read their own profile and edit non-billing fields.
-- is_pro / stripe_* are only written by the Stripe webhook (service role).
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles
  for select using (auth.uid() = id);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id)
  with check (auth.uid() = id);

revoke update on public.profiles from authenticated;
grant update (full_name) on public.profiles to authenticated;

-- habits
drop policy if exists "habits_crud_own" on public.habits;
create policy "habits_crud_own" on public.habits
  for all using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- habit_logs
drop policy if exists "habit_logs_crud_own" on public.habit_logs;
create policy "habit_logs_crud_own" on public.habit_logs
  for all using (auth.uid() = user_id)
  with check (
    auth.uid() = user_id
    and exists (select 1 from public.habits h where h.id = habit_id and h.user_id = auth.uid())
  );

-- weekly_reflections
drop policy if exists "weekly_reflections_crud_own" on public.weekly_reflections;
create policy "weekly_reflections_crud_own" on public.weekly_reflections
  for all using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- ---------------------------------------------------------------------------
-- Auto-create a profile row whenever a user signs up
-- ---------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data ->> 'full_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
