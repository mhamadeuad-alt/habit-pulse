-- HabitPulse: subscription lifecycle + hardened RLS. Safe to re-run.

-- Track the raw Stripe status (active, trialing, past_due, canceled, ...)
alter table public.profiles
  add column if not exists subscription_status text not null default 'none';

-- Webhook idempotency ledger. Only the service role (webhook) touches it.
create table if not exists public.stripe_events (
  id text primary key,
  type text not null,
  received_at timestamptz not null default now()
);
alter table public.stripe_events enable row level security;
revoke all on public.stripe_events from anon, authenticated;

-- Force RLS so even table owners can't bypass policies by accident.
alter table public.profiles force row level security;
alter table public.habits force row level security;
alter table public.habit_logs force row level security;
alter table public.weekly_reflections force row level security;

-- Anonymous visitors get no access to user data at all.
revoke all on public.profiles, public.habits, public.habit_logs, public.weekly_reflections from anon;

-- Billing columns stay read-only to end users; only full_name is writable.
revoke update on public.profiles from authenticated;
grant update (full_name) on public.profiles to authenticated;
revoke insert, delete on public.profiles from authenticated;

-- Reflections may only reference the caller's own habits.
drop policy if exists "weekly_reflections_crud_own" on public.weekly_reflections;
create policy "weekly_reflections_crud_own" on public.weekly_reflections
  for all to authenticated
  using (auth.uid() = user_id)
  with check (
    auth.uid() = user_id
    and (
      habit_id is null
      or exists (select 1 from public.habits h where h.id = habit_id and h.user_id = auth.uid())
    )
  );

-- Scope remaining policies to the authenticated role explicitly.
drop policy if exists "habits_crud_own" on public.habits;
create policy "habits_crud_own" on public.habits
  for all to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "habit_logs_crud_own" on public.habit_logs;
create policy "habit_logs_crud_own" on public.habit_logs
  for all to authenticated
  using (auth.uid() = user_id)
  with check (
    auth.uid() = user_id
    and exists (select 1 from public.habits h where h.id = habit_id and h.user_id = auth.uid())
  );

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles
  for select to authenticated using (auth.uid() = id);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
  for update to authenticated
  using (auth.uid() = id)
  with check (auth.uid() = id);
