

## Supabase production configuration

The local environment now contains the supplied Supabase URL, publishable key, and server-only service-role key. The existing auth and cloud data paths use `getSupabaseBrowserClient`, `fetchRemoteState`, and the remote habit/log/reflection writers whenever an authenticated Supabase session exists.

`/auth/v1/settings` responds successfully from the configured project. The project did not yet expose the expected `profiles`, `habits`, `habit_logs`, or `weekly_reflections` REST tables (404 during verification), so `supabase/schema.sql` is included for one-time execution in Supabase Dashboard → SQL Editor. Database persistence can be fully verified after that schema is applied and a real user signs in.
