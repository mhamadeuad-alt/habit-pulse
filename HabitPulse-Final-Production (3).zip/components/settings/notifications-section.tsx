'use client'

import { useEffect, useState } from 'react'
import { Bell, BellOff, BellRing, CircleCheck, ExternalLink, Loader2, RefreshCw, ShieldAlert } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Switch } from '@/components/ui/switch'
import { useReminderSettings, type NotificationSupport } from '@/hooks/use-reminders'
import { cn } from '@/lib/utils'
import { SettingRow } from './setting-row'
import { useLocale } from '@/lib/i18n'

const STATUS: Record<NotificationSupport, { label: string; className: string }> = {
  granted: { label: 'Allowed', className: 'border-primary/30 bg-primary/10 text-primary' },
  denied: { label: 'Blocked', className: 'border-destructive/30 bg-destructive/10 text-destructive' },
  default: { label: 'Not asked yet', className: 'border-border bg-muted text-muted-foreground' },
  unsupported: { label: 'Not supported', className: 'border-border bg-muted text-muted-foreground' },
}

export function NotificationsSection() {
  const r = useReminderSettings()
  const { t } = useLocale()
  const [requesting, setRequesting] = useState(false)
  const status = STATUS[r.permission]

  // The user may fix the setting in another tab/OS dialog and come back: re-read on focus.
  const { recheck } = r
  useEffect(() => {
    const onVisible = () => document.visibilityState === 'visible' && recheck()
    window.addEventListener('focus', recheck)
    document.addEventListener('visibilitychange', onVisible)
    return () => {
      window.removeEventListener('focus', recheck)
      document.removeEventListener('visibilitychange', onVisible)
    }
  }, [recheck])

  async function turnOn() {
    setRequesting(true)
    try {
      await r.setEnabled(true)
    } finally {
      setRequesting(false)
    }
  }

  async function handleMasterSwitch(next: boolean) {
    if (!next) {
      await r.setEnabled(false)
      return
    }
    // A reminders preference left on while permission was revoked just needs the fallback or a fix.
    if (r.enabled && r.blocked && !r.inApp) {
      toast.error('Notifications are blocked', { description: 'Use in-app reminders or allow them in your browser.' })
      return
    }
    await turnOn()
  }

  function handleCheckAgain() {
    const next = r.recheck()
    if (next === 'granted') {
      toast.success('Notifications are allowed now.')
      void r.setEnabled(true)
    } else if (next === 'denied') {
      toast.error('Still blocked in your browser settings.')
    } else {
      toast('Permission hasn’t changed yet.')
    }
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Daily reminders</CardTitle>
          <CardDescription>
            Get a nudge at each habit’s target time. Habits you’ve already checked off stay quiet.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-5">
          <SettingRow
            title="Enable reminders"
            htmlFor="reminders-switch"
            description="Reminders fire while HabitPulse is open in a browser tab."
          >
            {requesting && <Loader2 className="size-4 animate-spin text-muted-foreground" aria-hidden="true" />}
            <Switch
              id="reminders-switch"
              checked={r.active}
              disabled={requesting}
              onCheckedChange={(checked) => void handleMasterSwitch(checked)}
            />
          </SettingRow>

          <div className="h-px bg-border" role="separator" />

          <SettingRow
            title="Browser permission"
            description="Needed to show system notifications. Stored by your browser, per site."
          >
            <span
              className={cn(
                'inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold',
                status.className,
              )}
            >
              {status.label}
            </span>
          </SettingRow>

          {r.permission === 'default' && (
            <div className="flex flex-col gap-3 rounded-lg border border-border bg-muted/40 p-4 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm text-muted-foreground">
                Your browser will ask for permission. Choose <strong className="text-foreground">Allow</strong> to
                get system notifications.
              </p>
              <Button onClick={() => void turnOn()} disabled={requesting} className="shrink-0">
                <Bell data-icon="inline-start" aria-hidden="true" />
                Allow notifications
              </Button>
            </div>
          )}

          {r.permission === 'granted' && (
            <SettingRow
              title="Send a test"
              description={r.active ? 'Check that notifications reach you.' : 'Turn reminders on first to use them.'}
            >
              <Button variant="outline" onClick={r.sendTest} disabled={!r.active}>
                <BellRing data-icon="inline-start" aria-hidden="true" />
                Send test notification
              </Button>
            </SettingRow>
          )}

          <div className="flex flex-col gap-3 rounded-lg border border-pro/25 bg-pro/10 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex flex-col gap-1">
              <p className="text-sm font-semibold text-foreground">{t('smartNudges')}</p>
              <p className="text-sm text-muted-foreground">{t('nudgePreviewDescription')}</p>
            </div>
            <Button variant="outline" onClick={r.sendNudgePreview} className="shrink-0">
              <BellRing data-icon="inline-start" aria-hidden="true" />
              {t('nudgePreview')}
            </Button>
          </div>
        </CardContent>
      </Card>

      {r.blocked && <BlockedFallback {...r} onCheckAgain={handleCheckAgain} />}
    </>
  )
}

function BlockedFallback({
  permission,
  embedded,
  inApp,
  setInApp,
  sendTest,
  onCheckAgain,
}: ReturnType<typeof useReminderSettings> & { onCheckAgain: () => void }) {
  const unsupported = permission === 'unsupported'

  return (
    <Card className="ring-destructive/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShieldAlert className="size-4 text-destructive" aria-hidden="true" />
          {unsupported ? 'This browser can’t show notifications' : 'Notifications are blocked'}
        </CardTitle>
        <CardDescription>
          {unsupported
            ? 'Your browser doesn’t support system notifications here, but you can still be reminded inside the app.'
            : 'HabitPulse can’t send system notifications until you allow them. You have two options.'}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        <SettingRow
          title="Use in-app reminders"
          htmlFor="in-app-switch"
          description="Show reminders as pop-ups inside HabitPulse. No permission needed, but you must have the app open."
        >
          <Switch id="in-app-switch" checked={inApp} onCheckedChange={(checked) => setInApp(checked)} />
          <Button variant="outline" size="sm" onClick={sendTest} aria-label="Preview an in-app reminder">
            Preview
          </Button>
        </SettingRow>

        {!unsupported && (
          <div className="flex flex-col gap-3 rounded-lg border border-border bg-muted/40 p-4">
            <p className="flex items-center gap-2 text-sm font-medium">
              <BellOff className="size-4 text-muted-foreground" aria-hidden="true" />
              Or allow notifications in your browser
            </p>
            {embedded && (
              <p className="rounded-md border border-pro/30 bg-pro/10 p-2.5 text-sm text-foreground/90">
                This page is embedded in another site, and browsers block notification prompts there. Open it in
                its own tab first.{' '}
                <a
                  href={typeof window === 'undefined' ? '/settings' : window.location.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 font-medium underline underline-offset-4"
                >
                  Open in new tab
                  <ExternalLink className="size-3" aria-hidden="true" />
                </a>
              </p>
            )}
            <ol className="flex list-decimal flex-col gap-1.5 pl-5 text-sm text-muted-foreground">
              <li>Click the lock or settings icon next to the address bar.</li>
              <li>
                Open <span className="text-foreground">Site settings</span> (or{' '}
                <span className="text-foreground">Permissions</span>) and find{' '}
                <span className="text-foreground">Notifications</span>.
              </li>
              <li>
                Change it to <span className="text-foreground">Allow</span>, then come back here.
              </li>
            </ol>
            <div>
              <Button variant="outline" onClick={onCheckAgain}>
                <RefreshCw data-icon="inline-start" aria-hidden="true" />
                I’ve allowed it — check again
              </Button>
            </div>
          </div>
        )}

        {unsupported && (
          <p className="flex items-start gap-2 text-sm text-muted-foreground">
            <CircleCheck className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
            On iPhone and iPad, notifications only work for sites added to the Home Screen (Share → Add to Home
            Screen).
          </p>
        )}
      </CardContent>
    </Card>
  )
}
