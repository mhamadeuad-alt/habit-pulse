'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { Activity, ArrowLeft, Bell, Palette, UserRound } from 'lucide-react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useAuth } from '@/hooks/use-auth'
import { AuthDialog, type AuthView } from '@/components/habitpulse/auth-dialog'
import { ThemeToggle } from '@/components/habitpulse/theme-toggle'
import { AccountSection } from './account-section'
import { NotificationsSection } from './notifications-section'
import { WellnessRemindersSection } from './wellness-reminders-section'
import { PreferencesSection } from './preferences-section'
import { useLocale } from '@/lib/i18n'

const TABS = ['account', 'preferences', 'notifications'] as const
type TabValue = (typeof TABS)[number]

function parseTab(value: string | null): TabValue {
  if (value === 'security') return 'account'
  return (TABS as readonly string[]).includes(value ?? '') ? (value as TabValue) : 'account'
}

/**
 * Standalone /settings route: its own header and layout, no dependency on the dashboard.
 * Preferences and notifications work signed-out; the account tab asks you to sign in.
 */
export function SettingsPage() {
  const { t } = useLocale()
  const auth = useAuth()
  const params = useSearchParams()
  const [tab, setTab] = useState<TabValue>(() => parseTab(params.get('tab')))
  const [authView, setAuthView] = useState<AuthView | null>(null)
  const recovery = params.get('recovery') === '1'

  function changeTab(next: TabValue) {
    setTab(next)
    const url = new URL(window.location.href)
    url.searchParams.set('tab', next)
    url.searchParams.delete('recovery')
    window.history.replaceState(null, '', url)
  }

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/80 backdrop-blur-xl">
        <div className="mx-auto flex h-16 w-full max-w-3xl items-center justify-between gap-3 px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <Link
              href="/"
              className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              <ArrowLeft className="size-4" aria-hidden="true" />
              {t('backToDashboard')}
            </Link>
          </div>
          <Link href="/" className="flex items-center gap-2" aria-label="HabitPulse home">
            <span className="flex size-7 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Activity className="size-4" strokeWidth={2.5} aria-hidden="true" />
            </span>
            <span className="hidden text-sm font-semibold tracking-tight sm:inline">HabitPulse</span>
          </Link>
          <ThemeToggle />
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col gap-6 px-4 py-8 sm:px-6">
        <div className="flex flex-col gap-1.5">
          <h1 className="text-3xl font-semibold tracking-tight">{t('settings')}</h1>
          <p className="text-muted-foreground">{t('manageSettings')}</p>
        </div>

        <Tabs value={tab} onValueChange={(v) => changeTab(parseTab(String(v)))} className="gap-6">
          <TabsList className="h-10! w-full sm:w-fit">
            <TabsTrigger value="account" className="px-3">
              <UserRound aria-hidden="true" />
              {t('account')}
            </TabsTrigger>
            <TabsTrigger value="preferences" className="px-3">
              <Palette aria-hidden="true" />
              {t('preferences')}
            </TabsTrigger>
            <TabsTrigger value="notifications" className="px-3">
              <Bell aria-hidden="true" />
              {t('notifications')}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="account" className="flex flex-col gap-6">
            <AccountSection
              auth={auth}
              recovery={recovery}
              onSignIn={() => setAuthView('sign-in')}
              onSignUp={() => setAuthView('sign-up')}
            />
          </TabsContent>
          <TabsContent value="preferences" className="flex flex-col gap-6">
            <PreferencesSection auth={auth} />
          </TabsContent>
          <TabsContent value="notifications" className="flex flex-col gap-6">
            <NotificationsSection />
            <WellnessRemindersSection />
          </TabsContent>
        </Tabs>
      </main>

      <AuthDialog view={authView} onViewChange={setAuthView} supabase={auth.supabase} next="/settings" />
    </div>
  )
}
