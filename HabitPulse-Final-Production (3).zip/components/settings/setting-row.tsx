import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'

/** Label + description on the left, control on the right. Stacks on narrow screens. */
export function SettingRow({
  title,
  description,
  htmlFor,
  children,
  className,
}: {
  title: string
  description?: ReactNode
  htmlFor?: string
  children: ReactNode
  className?: string
}) {
  return (
    <div className={cn('flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between sm:gap-6', className)}>
      <div className="flex min-w-0 flex-col gap-1">
        <label htmlFor={htmlFor} className="text-sm font-medium text-foreground">
          {title}
        </label>
        {description && <p className="text-sm text-muted-foreground">{description}</p>}
      </div>
      <div className="flex shrink-0 items-center gap-2">{children}</div>
    </div>
  )
}
