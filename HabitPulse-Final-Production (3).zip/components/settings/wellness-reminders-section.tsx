'use client'

import { Droplets, Leaf, Smartphone } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Switch } from '@/components/ui/switch'
import { useLocale } from '@/lib/i18n'
import { useWellnessReminders, type WellnessReminderKey } from '@/hooks/use-wellness-reminders'
import { SettingRow } from './setting-row'

const REMINDERS: Array<{ key: WellnessReminderKey; icon: typeof Droplets; title: string; description: string }> = [
  { key: 'hydration', icon: Droplets, title: 'hydrationReminder', description: 'hydrationReminderDescription' },
  { key: 'digitalDetox', icon: Smartphone, title: 'digitalDetoxReminder', description: 'digitalDetoxReminderDescription' },
  { key: 'mindfulness', icon: Leaf, title: 'mindfulnessReminder', description: 'mindfulnessReminderDescription' },
]

export function WellnessRemindersSection() {
  const { t } = useLocale()
  const { preferences, setReminder } = useWellnessReminders()

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('wellnessReminders')}</CardTitle>
        <CardDescription>{t('wellnessRemindersDescription')}</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        {REMINDERS.map(({ key, icon: Icon, title, description }, index) => (
          <div key={key} className="flex flex-col gap-5">
            {index > 0 && <div className="h-px bg-border" role="separator" />}
            <SettingRow title={t(title)} htmlFor={`wellness-${key}`} description={t(description)}>
              <span className="flex size-8 items-center justify-center rounded-lg bg-primary/10 text-primary" aria-hidden="true">
                <Icon className="size-4" />
              </span>
              <Switch
                id={`wellness-${key}`}
                checked={preferences[key]}
                onCheckedChange={(checked) => setReminder(key, checked)}
                aria-label={t(title)}
              />
            </SettingRow>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
