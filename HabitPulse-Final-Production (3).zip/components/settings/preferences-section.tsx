'use client'

import { useEffect, useState } from 'react'
import { FileJson, FileSpreadsheet, Monitor, Moon, Sun } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useHabitData } from '@/hooks/use-habit-data'
import type { AuthState } from '@/hooks/use-auth'
import { downloadExport, type ExportFormat } from '@/lib/export'
import { cn } from '@/lib/utils'
import { SettingRow } from './setting-row'
import { useLocale } from '@/lib/i18n'
import { useTheme } from '@/components/theme-provider'

const THEMES = [
  { value: 'light', label: 'Light', icon: Sun },
  { value: 'dark', label: 'Dark', icon: Moon },
  { value: 'system', label: 'System', icon: Monitor },
] as const

export function PreferencesSection({ auth }: { auth: AuthState }) {
  const { locale, setLocale, t } = useLocale()
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  // next-themes only knows the stored theme on the client; wait to avoid a hydration mismatch.
  useEffect(() => setMounted(true), [])

  const data = useHabitData(auth.supabase, auth.user)

  function handleExport(format: ExportFormat) {
    if (!data.state) return
    downloadExport(data.state, format, new Date())
    toast.success(`Exported ${format.toUpperCase()}`)
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>{t('appearance')}</CardTitle>
          <CardDescription>{t('appearanceDescription')}</CardDescription>
        </CardHeader>
        <CardContent>
          <div role="radiogroup" aria-label="Color theme" className="grid grid-cols-3 gap-2 sm:max-w-sm">
            {THEMES.map(({ value, label, icon: Icon }) => {
              const selected = mounted && theme === value
              return (
                <button
                  key={value}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => setTheme(value)}
                  className={cn(
                    'flex flex-col items-center gap-2 rounded-lg border p-3 text-sm font-medium transition-colors outline-none focus-visible:ring-3 focus-visible:ring-ring/50',
                    selected
                      ? 'border-primary bg-primary/10 text-foreground'
                      : 'border-border text-muted-foreground hover:bg-muted hover:text-foreground',
                  )}
                >
                  <Icon className="size-5" aria-hidden="true" />
                  {value === 'light' ? t('light') : value === 'dark' ? t('dark') : t('system')}
                </button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('language')}</CardTitle>
          <CardDescription>{t('languageDescription')}</CardDescription>
        </CardHeader>
        <CardContent>
          <div role="radiogroup" aria-label={t('language')} className="grid grid-cols-2 gap-2 sm:max-w-sm">
            {([['en', t('english')], ['ar', t('arabic')]] as const).map(([value, label]) => (
              <button key={value} type="button" role="radio" aria-checked={locale === value} onClick={() => setLocale(value)} className={cn('rounded-lg border p-3 text-sm font-medium transition-colors', locale === value ? 'border-primary bg-primary/10 text-foreground' : 'border-border text-muted-foreground hover:bg-muted hover:text-foreground')}>
                {label}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('yourData')}</CardTitle>
          <CardDescription>
            {data.mode === 'cloud' ? t('dataCloud') : 'Sign in to manage and sync your habits.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <SettingRow title={t('exportHabits')} description={t('completionsNotes')}>
            <Button variant="outline" disabled={!data.state} onClick={() => handleExport('csv')}>
              <FileSpreadsheet data-icon="inline-start" aria-hidden="true" />
              CSV
            </Button>
            <Button variant="outline" disabled={!data.state} onClick={() => handleExport('json')}>
              <FileJson data-icon="inline-start" aria-hidden="true" />
              JSON
            </Button>
          </SettingRow>
        </CardContent>
      </Card>
    </>
  )
}
