'use client'

import { useEffect, useRef, useState, type FormEvent } from 'react'
import { useRouter } from 'next/navigation'
import { Info, KeyRound, Loader2, LogIn, LogOut, MonitorSmartphone, Trash2, TriangleAlert, UserPlus } from 'lucide-react'
import { toast } from 'sonner'
import type { User } from '@supabase/supabase-js'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { GoogleIcon } from '@/components/habitpulse/google-icon'
import type { AuthState } from '@/hooks/use-auth'
import { getAvatarUrl, getDisplayName, getProviders } from '@/lib/auth'
import { SettingRow } from './setting-row'

interface AccountSectionProps {
  auth: AuthState
  recovery: boolean
  onSignIn: () => void
  onSignUp: () => void
}

export function AccountSection({ auth, recovery, onSignIn, onSignUp }: AccountSectionProps) {
  const { supabase, user, ready } = auth

  if (!ready) {
    return (
      <div className="flex animate-pulse flex-col gap-6" aria-busy="true" aria-label="Loading account">
        <div className="h-48 rounded-xl bg-card" />
        <div className="h-64 rounded-xl bg-card" />
      </div>
    )
  }

  if (!supabase) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Info className="size-4 text-pro" aria-hidden="true" />
            Accounts aren’t connected yet
          </CardTitle>
          <CardDescription>Authentication is unavailable until Supabase is configured.</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  if (!user) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Sign in to manage your account</CardTitle>
          <CardDescription>
            Sync habits across devices, change your name and password, and keep your streaks safe.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button size="lg" onClick={onSignIn}>
            <LogIn data-icon="inline-start" aria-hidden="true" />
            Sign in
          </Button>
          <Button size="lg" variant="outline" onClick={onSignUp}>
            <UserPlus data-icon="inline-start" aria-hidden="true" />
            Create account
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <ProfileCard auth={auth} user={user} />
      <SignInCard auth={auth} user={user} recovery={recovery} />
      <SessionCard auth={auth} />
      <DangerCard auth={auth} />
    </>
  )
}

type Props = { auth: AuthState; user: User }

/* -------------------------------------------------------------------------- */
/* Profile                                                                     */
/* -------------------------------------------------------------------------- */

function ProfileCard({ auth, user }: Props) {
  const { supabase } = auth
  const meta = user.user_metadata ?? {}
  const current = String(meta.full_name ?? meta.name ?? '').trim()
  const [name, setName] = useState(current)
  const [saving, setSaving] = useState(false)
  const avatarUrl = getAvatarUrl(user)
  const shown = getDisplayName(user)
  const trimmed = name.trim()
  const dirty = trimmed !== current.trim()

  async function save(event: FormEvent) {
    event.preventDefault()
    if (!supabase || !dirty) return
    if (trimmed.length > 80) {
      toast.error('Names can be up to 80 characters.')
      return
    }
    setSaving(true)
    const { error } = await supabase.auth.updateUser({ data: { full_name: trimmed } })
    if (error) {
      setSaving(false)
      toast.error(error.message)
      return
    }
    // Keep the public profile row in step with the auth metadata (full_name is the only writable column).
    const { error: profileError } = await supabase.from('profiles').update({ full_name: trimmed }).eq('id', user.id)
    setSaving(false)
    if (profileError) {
      toast.error('Saved your name, but could not update your profile record.')
      return
    }
    toast.success('Profile updated')
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Profile</CardTitle>
        <CardDescription>How you’re greeted on the dashboard.</CardDescription>
      </CardHeader>
      <form onSubmit={save}>
        <CardContent className="flex flex-col gap-5">
          <div className="flex items-center gap-4">
            <Avatar size="lg" className="size-14">
              {avatarUrl && <AvatarImage src={avatarUrl} alt="" referrerPolicy="no-referrer" />}
              <AvatarFallback className="bg-secondary text-base font-semibold text-foreground">
                {shown.slice(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex min-w-0 flex-col">
              <span className="truncate text-sm font-medium">{shown}</span>
              <span className="truncate text-sm text-muted-foreground">{user.email}</span>
            </div>
          </div>
          <div className="flex flex-col gap-2 sm:max-w-sm">
            <Label htmlFor="settings-name">Display name</Label>
            <Input
              id="settings-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
              maxLength={80}
              placeholder="Alex Rivera"
            />
          </div>
        </CardContent>
        <CardFooter className="mt-(--card-spacing) justify-end">
          <Button type="submit" disabled={!dirty || saving}>
            {saving && <Loader2 className="animate-spin" data-icon="inline-start" aria-hidden="true" />}
            Save changes
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

/* -------------------------------------------------------------------------- */
/* Sign-in methods: providers, email, password                                 */
/* -------------------------------------------------------------------------- */

function SignInCard({ auth, user, recovery }: Props & { recovery: boolean }) {
  const { supabase } = auth
  const providers = getProviders(user)
  const hasPassword = providers.includes('email')
  const hasGoogle = providers.includes('google')

  const [email, setEmail] = useState('')
  const [emailPending, setEmailPending] = useState(false)

  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [passwordError, setPasswordError] = useState<string | null>(null)
  const [passwordPending, setPasswordPending] = useState(false)
  const passwordRef = useRef<HTMLInputElement>(null)
  const passwordCardRef = useRef<HTMLDivElement>(null)

  // Arriving from a password-reset email: bring the new-password form into view.
  useEffect(() => {
    if (!recovery) return
    passwordCardRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    passwordRef.current?.focus({ preventScroll: true })
  }, [recovery])

  async function changeEmail(event: FormEvent) {
    event.preventDefault()
    const next = email.trim()
    if (!supabase || !next || next.toLowerCase() === user.email?.toLowerCase()) return
    setEmailPending(true)
    const { error } = await supabase.auth.updateUser(
      { email: next },
      { emailRedirectTo: `${window.location.origin}/auth/callback?next=${encodeURIComponent('/settings')}` },
    )
    setEmailPending(false)
    if (error) {
      toast.error(error.message)
      return
    }
    setEmail('')
    toast.success('Check your inbox', { description: 'Click the confirmation link to finish changing your email.' })
  }

  async function changePassword(event: FormEvent) {
    event.preventDefault()
    if (!supabase) return
    if (password.length < 8) return setPasswordError('Use at least 8 characters.')
    if (password !== confirm) return setPasswordError('Passwords don’t match.')
    setPasswordError(null)
    setPasswordPending(true)
    const { error } = await supabase.auth.updateUser({ password })
    setPasswordPending(false)
    if (error) {
      setPasswordError(error.message)
      return
    }
    setPassword('')
    setConfirm('')
    toast.success(hasPassword ? 'Password updated' : 'Password added', {
      description: hasPassword ? undefined : 'You can now sign in with email and password too.',
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sign-in &amp; security</CardTitle>
        <CardDescription>How you get into HabitPulse.</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-6">
        <div className="flex flex-col gap-3">
          <h3 className="text-sm font-medium">Connected methods</h3>
          <ul className="flex flex-col gap-2">
            {hasGoogle && (
              <li className="flex items-center gap-3 rounded-lg border border-border p-3 text-sm">
                <GoogleIcon className="size-4" />
                <span className="font-medium">Google</span>
                <span className="truncate text-muted-foreground">{user.email}</span>
              </li>
            )}
            {hasPassword && (
              <li className="flex items-center gap-3 rounded-lg border border-border p-3 text-sm">
                <KeyRound className="size-4 text-muted-foreground" aria-hidden="true" />
                <span className="font-medium">Email &amp; password</span>
                <span className="truncate text-muted-foreground">{user.email}</span>
              </li>
            )}
          </ul>
        </div>

        {hasPassword && (
          <>
            <div className="h-px bg-border" role="separator" />
            <form onSubmit={changeEmail} className="flex flex-col gap-3">
              <Label htmlFor="settings-email">Change email</Label>
              <div className="flex flex-col gap-2 sm:max-w-md sm:flex-row">
                <Input
                  id="settings-email"
                  type="email"
                  autoComplete="email"
                  placeholder="new@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <Button type="submit" variant="outline" disabled={!email.trim() || emailPending}>
                  {emailPending && <Loader2 className="animate-spin" data-icon="inline-start" aria-hidden="true" />}
                  Update
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">We’ll email a confirmation link before anything changes.</p>
            </form>
          </>
        )}

        <div className="h-px bg-border" role="separator" />

        <div ref={passwordCardRef} className="flex flex-col gap-3">
          {recovery && (
            <p className="rounded-md border border-pro/30 bg-pro/10 p-2.5 text-sm text-foreground/90" role="status">
              You’re signed in from a reset link. Choose a new password below.
            </p>
          )}
          <form onSubmit={changePassword} className="flex flex-col gap-3 sm:max-w-md">
            <h3 className="text-sm font-medium">{hasPassword ? 'Change password' : 'Add a password'}</h3>
            {!hasPassword && (
              <p className="text-sm text-muted-foreground">
                You currently sign in with Google. Adding a password lets you use email sign-in too.
              </p>
            )}
            <div className="flex flex-col gap-2">
              <Label htmlFor="settings-password">New password</Label>
              <Input
                id="settings-password"
                ref={passwordRef}
                type="password"
                autoComplete="new-password"
                minLength={8}
                placeholder="At least 8 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="settings-password-confirm">Confirm new password</Label>
              <Input
                id="settings-password-confirm"
                type="password"
                autoComplete="new-password"
                minLength={8}
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
              />
            </div>
            {passwordError && (
              <p role="alert" className="text-sm text-destructive">
                {passwordError}
              </p>
            )}
            <div>
              <Button type="submit" disabled={!password || !confirm || passwordPending}>
                {passwordPending && <Loader2 className="animate-spin" data-icon="inline-start" aria-hidden="true" />}
                {hasPassword ? 'Update password' : 'Add password'}
              </Button>
            </div>
          </form>
        </div>
      </CardContent>
    </Card>
  )
}

/* -------------------------------------------------------------------------- */
/* Sessions                                                                    */
/* -------------------------------------------------------------------------- */

function SessionCard({ auth }: { auth: AuthState }) {
  const { supabase } = auth
  const router = useRouter()
  const [pending, setPending] = useState<'others' | 'this' | null>(null)

  async function signOutOthers() {
    if (!supabase) return
    setPending('others')
    const { error } = await supabase.auth.signOut({ scope: 'others' })
    setPending(null)
    if (error) toast.error(error.message)
    else toast.success('Signed out of your other devices')
  }

  async function signOutHere() {
    setPending('this')
    await auth.signOut()
    toast.success('Signed out')
    router.push('/')
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sessions</CardTitle>
        <CardDescription>Control where you’re signed in.</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        <SettingRow title="Other devices" description="Sign out everywhere except this browser.">
          <Button variant="outline" onClick={signOutOthers} disabled={pending !== null}>
            {pending === 'others' ? (
              <Loader2 className="animate-spin" data-icon="inline-start" aria-hidden="true" />
            ) : (
              <MonitorSmartphone data-icon="inline-start" aria-hidden="true" />
            )}
            Sign out others
          </Button>
        </SettingRow>
        <div className="h-px bg-border" role="separator" />
        <SettingRow title="This device" description="You’ll return to the dashboard after signing out.">
          <Button variant="outline" onClick={signOutHere} disabled={pending !== null}>
            {pending === 'this' ? (
              <Loader2 className="animate-spin" data-icon="inline-start" aria-hidden="true" />
            ) : (
              <LogOut data-icon="inline-start" aria-hidden="true" />
            )}
            Sign out
          </Button>
        </SettingRow>
      </CardContent>
    </Card>
  )
}

/* -------------------------------------------------------------------------- */
/* Delete account                                                              */
/* -------------------------------------------------------------------------- */

function DangerCard({ auth }: { auth: AuthState }) {
  const { supabase, session } = auth
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [confirm, setConfirm] = useState('')
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function deleteAccount() {
    if (!supabase || !session) return
    setPending(true)
    setError(null)
    try {
      const response = await fetch('/api/account', {
        method: 'DELETE',
        headers: { authorization: `Bearer ${session.access_token}` },
      })
      const result = (await response.json().catch(() => ({}))) as { error?: string }
      if (!response.ok) {
        setError(result.error ?? 'Could not delete your account.')
        setPending(false)
        return
      }
      // The server session is gone with the user; clear only the local copy.
      await supabase.auth.signOut({ scope: 'local' })
      toast.success('Your account was deleted')
      router.push('/')
    } catch {
      setError('Network error. Please try again.')
      setPending(false)
    }
  }

  return (
    <>
      <Card className="ring-destructive/30">
        <CardHeader>
          <CardTitle className="text-destructive">Delete account</CardTitle>
          <CardDescription>
            Permanently removes your account, habits, notes and reflections. An active Pro subscription is cancelled.
            This can’t be undone.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button variant="destructive" onClick={() => setOpen(true)}>
            <Trash2 data-icon="inline-start" aria-hidden="true" />
            Delete my account
          </Button>
        </CardContent>
      </Card>

      <Dialog
        open={open}
        onOpenChange={(next) => {
          if (pending) return
          setOpen(next)
          if (!next) {
            setConfirm('')
            setError(null)
          }
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <TriangleAlert className="size-4" aria-hidden="true" />
              Delete your account?
            </DialogTitle>
            <DialogDescription>
              All of your data will be erased. Consider exporting it from the Preferences tab first. Type{' '}
              <strong className="text-foreground">DELETE</strong> to confirm.
            </DialogDescription>
          </DialogHeader>
          <Input
            aria-label="Type DELETE to confirm"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            autoComplete="off"
            placeholder="DELETE"
          />
          {error && (
            <p role="alert" className="text-sm text-destructive">
              {error}
            </p>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} disabled={pending}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={deleteAccount}
              disabled={confirm !== 'DELETE' || pending}
            >
              {pending && <Loader2 className="animate-spin" data-icon="inline-start" aria-hidden="true" />}
              Delete forever
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
