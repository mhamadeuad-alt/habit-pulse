'use client'

import { useState } from 'react'
import { Check, PenLine } from 'lucide-react'
import { Textarea } from '@/components/ui/textarea'
import { useLocale } from '@/lib/i18n'

interface WeeklyReflectionProps {
  initialValue: string
  onCommit: (text: string) => void
}

export function WeeklyReflection({ initialValue, onCommit }: WeeklyReflectionProps) {
  const { t } = useLocale()
  const [draft, setDraft] = useState(initialValue)
  const [savedValue, setSavedValue] = useState(initialValue)
  const isDirty = draft !== savedValue

  function commit() {
    if (!isDirty) return
    onCommit(draft)
    setSavedValue(draft)
  }

  return (
    <section aria-labelledby="reflection-heading" className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary/15 text-primary">
            <PenLine className="size-4" aria-hidden="true" />
          </span>
          <div className="flex flex-col">
            <h2 id="reflection-heading" className="text-base font-semibold tracking-tight">
              {t('weeklyReflection')}
            </h2>
            <p className="text-xs text-muted-foreground">{t('reflectionDescription')}</p>
          </div>
        </div>
        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground" aria-live="polite">
          {isDirty ? (
            t('unsaved')
          ) : (
            <>
              <Check className="size-3.5 text-primary" aria-hidden="true" />
              {t('saved')}
            </>
          )}
        </span>
      </div>
      <label htmlFor="weekly-reflection" className="sr-only">
        {t('weeklyReflection')}
      </label>
      <Textarea
        id="weekly-reflection"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={commit}
        maxLength={4000}
        placeholder={t('reflectionPlaceholder')}
        className="min-h-36 flex-1 resize-y border-input bg-background/40 leading-relaxed"
      />
    </section>
  )
}
