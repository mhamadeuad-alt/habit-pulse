'use client'

import { useEffect, useMemo, useState } from 'react'
import { Activity, Cloud, HardDrive } from 'lucide-react'
import { toast } from 'sonner'
import { useAuth } from '@/hooks/use-auth'
import { useHabitData } from '@/hooks/use-habit-data'
import { useReminders } from '@/hooks/use-reminders'
import { downloadExport } from '@/lib/export'
import { StreakAnalytics } from './streak-analytics'
import {
  addDays,
  FREE_HABIT_LIMIT,
  getStreak,
  getWeekDays,
  getWeeklyTrend,
  isTrackableDay,
  startOfWeek,
  toISODate,
  type HabitState,
} from '@/lib/habits'
import { isSupabaseConfigured } from '@/lib/supabase'
import { AddHabitDialog } from './add-habit-dialog'
import { AuthDialog, type AuthView } from './auth-dialog'
import { HabitMatrix, type HabitRow } from './habit-matrix'
import { ProInsights } from './pro-insights'
import { SiteHeader } from './site-header'
import { SummaryCards } from './summary-cards'
import { UpgradeDialog } from './upgrade-dialog'
import { WeeklyReflection } from './weekly-reflection'
import { FocusTimer } from './focus-timer'
import { useLocale } from '@/lib/i18n'

/** Current date that rolls over at local midnight so "today", streaks and rates never go stale. */
function useToday() {
  const [today, setToday] = useState(() => new Date())
  useEffect(() => {
    const now = new Date()
    const nextMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 1)
    const timer = window.setTimeout(() => setToday(new Date()), nextMidnight.getTime() - now.getTime())
    const onVisible = () => {
      if (document.visibilityState === 'visible') {
        setToday((prev) => (prev.toDateString() === new Date().toDateString() ? prev : new Date()))
      }
    }
    document.addEventListener('visibilitychange', onVisible)
    return () => {
      window.clearTimeout(timer)
      document.removeEventListener('visibilitychange', onVisible)
    }
  }, [today])
  return today
}

export function HabitPulse() {
  const auth = useAuth()
  const data = useHabitData(auth.supabase, auth.user)
  const [authView, setAuthView] = useState<AuthView | null>(null)
  const [upgradeReason, setUpgradeReason] = useState<string | null>(null)
  const [upgradeOpen, setUpgradeOpen] = useState(false)
  const [addOpen, setAddOpen] = useState(false)
  const [weekOffset, setWeekOffset] = useState(0)
  const today = useToday()

  const state = data.state
  const reminders = useReminders(state)
  const currentStreak = useMemo(
    () => (state ? Math.max(0, ...state.habits.map((h) => getStreak(state.completions[h.id], today))) : 0),
    [state, today],
  )

  function openUpgrade(reason: string | null = null) {
    setUpgradeReason(reason)
    setUpgradeOpen(true)
  }

  async function startCheckout() {
    if (isSupabaseConfigured && !auth.session) {
      setUpgradeOpen(false)
      setAuthView('sign-up')
      toast.info('Create an account first so Pro is attached to you.')
      return
    }

    const headers: Record<string, string> = {
      'content-type': 'application/json',
      'idempotency-key': crypto.randomUUID(),
    }
    if (auth.session) headers.authorization = `Bearer ${auth.session.access_token}`

    const response = await fetch('/api/checkout', { method: 'POST', headers })
    const result = (await response.json().catch(() => ({}))) as {
      mode?: 'live'
      url?: string
      error?: string
    }

    if (!response.ok) {
      toast.error(result.error ?? 'Checkout is unavailable right now.')
      return
    }

    if (result.mode === 'live' && result.url) {
      if (window.self !== window.top) window.open(result.url, '_blank', 'noopener')
      else window.location.href = result.url
      return
    }

    toast.info('Stripe is not connected yet, so checkout is disabled.')
  }

  function handleAddClick() {
    if (!state) return
    if (!data.isPro && state.habits.length >= FREE_HABIT_LIMIT) {
      openUpgrade(`Free includes up to ${FREE_HABIT_LIMIT} habits. Go Pro for unlimited habits.`)
      return
    }
    setAddOpen(true)
  }

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader
        user={auth.user}
        isPro={data.isPro}
        currentStreak={currentStreak}
        onSignIn={() => setAuthView('sign-in')}
        onSignUp={() => setAuthView('sign-up')}
        onSignOut={async () => {
          await auth.signOut()
          toast.success('Signed out')
        }}
        onUpgrade={() => openUpgrade()}
        onExport={(format) => {
          if (!state) return
          downloadExport(state, format, today)
          toast.success(`Exported ${format.toUpperCase()}`)
        }}
        remindersEnabled={reminders.enabled}
        onRemindersChange={reminders.setEnabled}
      />

      <main className="mx-auto flex w-full max-w-6xl flex-1 flex-col gap-6 px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
        {state ? (
          <Dashboard
            state={state}
            today={today}
            weekOffset={weekOffset}
            setWeekOffset={setWeekOffset}
            isPro={data.isPro}
            authToken={auth.session?.access_token ?? null}
            displayName={(auth.user?.user_metadata?.full_name as string | undefined) || null}
            onAdd={handleAddClick}
            onUpgrade={() => openUpgrade()}
            onToggle={data.toggleCompletion}
            onRemove={(habitId) => {
              const habit = state.habits.find((h) => h.id === habitId)
              data.removeHabit(habitId)
              toast(`Removed "${habit?.name ?? 'habit'}"`)
            }}
            onNoteChange={data.setNote}
            onReflectionChange={data.setReflection}
          />
        ) : auth.ready && !auth.user ? (
          <SignInRequired onSignIn={() => setAuthView('sign-in')} onSignUp={() => setAuthView('sign-up')} />
        ) : (
          <DashboardSkeleton />
        )}
      </main>

      <footer className="border-t border-border/70">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-muted-foreground sm:flex-row sm:px-6 lg:px-8">
          <span>© {today.getFullYear()} HabitPulse</span>
          <span className="inline-flex items-center gap-1.5">
            {data.mode === 'cloud' ? (
              <>
                <Cloud className="size-3.5 text-primary" aria-hidden="true" />
                Synced with Supabase
              </>
            ) : (
              <>
                <HardDrive className="size-3.5" aria-hidden="true" />
                Sign in to sync your habits
              </>
            )}
          </span>
        </div>
      </footer>

      <AddHabitDialog open={addOpen} onOpenChange={setAddOpen} onAdd={data.addHabit} />
      <AuthDialog view={authView} onViewChange={setAuthView} supabase={auth.supabase} />
      <UpgradeDialog
        open={upgradeOpen}
        onOpenChange={setUpgradeOpen}
        reason={upgradeReason}
        onCheckout={startCheckout}
      />
    </div>
  )
}

interface DashboardProps {
  state: HabitState
  today: Date
  weekOffset: number
  setWeekOffset: (updater: (o: number) => number) => void
  isPro: boolean
  authToken: string | null
  displayName: string | null
  onAdd: () => void
  onUpgrade: () => void
  onToggle: (habitId: string, iso: string) => void
  onRemove: (habitId: string) => void
  onNoteChange: (weekKey: string, habitId: string, text: string) => void
  onReflectionChange: (weekKey: string, text: string) => void
}

function Dashboard({
  state,
  today,
  weekOffset,
  setWeekOffset,
  isPro,
  authToken,
  displayName,
  onAdd,
  onUpgrade,
  onToggle,
  onRemove,
  onNoteChange,
  onReflectionChange,
}: DashboardProps) {
  const { t, formatDate } = useLocale()
  const weekStart = useMemo(() => addDays(startOfWeek(today), weekOffset * 7), [today, weekOffset])
  const weekKey = toISODate(weekStart)
  const days = useMemo(() => getWeekDays(weekStart, today), [weekStart, today])

  const rows: HabitRow[] = useMemo(
    () =>
      state.habits.map((habit) => {
        const completedDays = state.completions[habit.id] ?? {}
        return {
          habit,
          completedDays,
          weekCount: days.filter((d) => completedDays[d.iso]).length,
          streak: getStreak(completedDays, today),
          note: state.notes[weekKey]?.[habit.id] ?? '',
        }
      }),
    [state, days, today, weekKey],
  )

  const summary = useMemo(() => {
    const trackable = days.filter((d) => isTrackableDay(d, rows.some((r) => r.completedDays[d.iso])))
    const possible = trackable.length * rows.length
    const completed = rows.reduce((sum, r) => sum + trackable.filter((d) => r.completedDays[d.iso]).length, 0)
    const perfectDayMap = days.map((day) => ({
      day,
      perfect: rows.length > 0 && rows.every((r) => r.completedDays[day.iso]),
    }))
    const best = rows.reduce<HabitRow | null>((top, r) => (!top || r.streak > top.streak ? r : top), null)
    return {
      possible,
      completed,
      completionRate: possible === 0 ? 0 : Math.round((completed / possible) * 100),
      bestStreak: best?.streak ?? 0,
      bestStreakHabit: best && best.streak > 0 ? best.habit.name : null,
      perfectDays: perfectDayMap.filter((p) => p.perfect).length,
      perfectDayMap,
    }
  }, [days, rows])

  const insights = useMemo(() => {
    const trend = getWeeklyTrend(state, today, 8)
    const windowStart = addDays(startOfWeek(today), -49)
    const windowDays = Array.from({ length: 56 }, (_, i) => addDays(windowStart, i)).filter((d) => d <= today)

    let mostConsistent: string | null = null
    let topCount = 0
    for (const habit of state.habits) {
      const count = windowDays.filter((d) => state.completions[habit.id]?.[toISODate(d)]).length
      if (count > topCount) {
        topCount = count
        mostConsistent = habit.name
      }
    }

    const weekdayTotals = new Map<number, number>()
    for (const d of windowDays) {
      const iso = toISODate(d)
      const done = state.habits.filter((h) => state.completions[h.id]?.[iso]).length
      weekdayTotals.set(d.getDay(), (weekdayTotals.get(d.getDay()) ?? 0) + done)
    }
    const bestDay = [...weekdayTotals.entries()].sort((a, b) => b[1] - a[1])[0]
    const bestWeekday =
      bestDay && bestDay[1] > 0
        ? formatDate(new Date(2024, 0, 7 + bestDay[0]), { weekday: 'long' })
        : null

    return { trend, mostConsistent, bestWeekday }
  }, [state, today])

  const weekEnd = addDays(weekStart, 6)
  const rangeLabel = `${formatDate(weekStart, { month: 'short', day: 'numeric' })} – ${formatDate(weekEnd, { month: 'short', day: 'numeric', year: 'numeric' })}`
  const hour = today.getHours()
  const greeting = hour < 12 ? t('morning') : hour < 18 ? t('afternoon') : t('evening')
  const todayIso = toISODate(today)
  const doneToday = rows.filter((r) => r.completedDays[todayIso]).length

  return (
    <>
      <div className="flex flex-col gap-1.5">
        <p className="text-sm font-medium text-primary">
          {formatDate(today, { weekday: 'long', month: 'long', day: 'numeric' })}
        </p>
        <h1 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
          {greeting}
          {displayName ? `, ${displayName.split(' ')[0]}` : ''}.
        </h1>
        <p className="text-muted-foreground">
          {rows.length === 0
            ? t('addFirst')
            : doneToday === rows.length
              ? t('allDone')
              : `${doneToday} of ${rows.length} habits done today. ${t('keepGoing')}`}
        </p>
      </div>

      {rows.length > 0 && doneToday < rows.length && currentStreakForRows(rows, today) > 0 && (
        <div className="flex items-start gap-3 rounded-2xl border border-flame/25 bg-flame/10 p-4 text-sm">
          <span className="mt-0.5 text-flame">⚡</span>
          <div><p className="font-semibold text-foreground">{t('streakInDanger')}</p><p className="mt-0.5 text-muted-foreground">{t('streakInDangerDescription')}</p></div>
        </div>
      )}

      <SummaryCards {...summary} />

      <HabitMatrix
        rows={rows}
        days={days}
        weekKey={weekKey}
        rangeLabel={rangeLabel}
        isCurrentWeek={weekOffset === 0}
        habitLimitLabel={isPro ? null : `${state.habits.length}/${FREE_HABIT_LIMIT} habits on Free`}
        onPrevWeek={() => setWeekOffset((o) => o - 1)}
        onNextWeek={() => setWeekOffset((o) => o + 1)}
        onThisWeek={() => setWeekOffset(() => 0)}
        onAdd={onAdd}
        onToggle={onToggle}
        onNoteChange={(habitId, text) => onNoteChange(weekKey, habitId, text)}
        onRemove={onRemove}
      />

      <FocusTimer />

      <StreakAnalytics state={state} today={today} />

      <div className="grid gap-6 lg:grid-cols-2">
        <WeeklyReflection
          key={weekKey}
          initialValue={state.reflections[weekKey] ?? ''}
          onCommit={(text) => onReflectionChange(weekKey, text)}
        />
        <ProInsights isPro={isPro} authToken={authToken} onUpgrade={onUpgrade} {...insights} />
      </div>
    </>
  )
}

function currentStreakForRows(rows: HabitRow[], today: Date) {
  return Math.max(0, ...rows.map((row) => getStreak(row.completedDays, today)))
}

function DashboardSkeleton() {
  return (
    <div className="flex animate-pulse flex-col gap-6" aria-busy="true" aria-label="Loading dashboard">
      <div className="flex flex-col gap-2">
        <div className="h-4 w-40 rounded bg-muted" />
        <div className="h-10 w-72 rounded-lg bg-muted" />
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <div key={i} className="h-32 rounded-2xl bg-card" />
        ))}
      </div>
      <div className="h-96 rounded-2xl bg-card" />
    </div>
  )
}

function SignInRequired({ onSignIn, onSignUp }: { onSignIn: () => void; onSignUp: () => void }) {
  return (
    <section className="mx-auto flex w-full max-w-xl flex-col items-center gap-5 rounded-2xl border border-border bg-card p-8 text-center sm:p-12">
      <span className="flex size-12 items-center justify-center rounded-xl bg-primary/15 text-primary">
        <Activity className="size-6" aria-hidden="true" />
      </span>
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-semibold tracking-tight">Welcome to HabitPulse</h1>
        <p className="text-sm leading-6 text-muted-foreground">
          Sign in to load your synced habits and continue building your streaks.
        </p>
      </div>
      <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row">
        <button
          type="button"
          onClick={onSignIn}
          className="inline-flex h-10 items-center justify-center rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
        >
          Sign in
        </button>
        <button
          type="button"
          onClick={onSignUp}
          className="inline-flex h-10 items-center justify-center rounded-lg border border-border px-5 text-sm font-semibold transition-colors hover:bg-secondary"
        >
          Create account
        </button>
      </div>
    </section>
  )
}
