'use client'

import {
  Activity,
  Bell,
  BellOff,
  Crown,
  FileJson,
  FileSpreadsheet,
  Flame,
  LogIn,
  LogOut,
  Settings,
  Sparkles,
  UserPlus,
} from 'lucide-react'
import Link from 'next/link'
import type { User } from '@supabase/supabase-js'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import type { ExportFormat } from '@/lib/export'
import { ThemeToggle } from './theme-toggle'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { getAvatarUrl, getDisplayName } from '@/lib/auth'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useLocale } from '@/lib/i18n'

interface SiteHeaderProps {
  user: User | null
  isPro: boolean
  currentStreak: number
  onSignIn: () => void
  onSignUp: () => void
  onSignOut: () => void
  onUpgrade: () => void
  onExport: (format: ExportFormat) => void
  remindersEnabled: boolean
  onRemindersChange: (enabled: boolean) => void
}

export function SiteHeader({
  user,
  isPro,
  currentStreak,
  onSignIn,
  onSignUp,
  onSignOut,
  onUpgrade,
  onExport,
  remindersEnabled,
  onRemindersChange,
}: SiteHeaderProps) {
  const { t } = useLocale()
  const displayName = getDisplayName(user)
  const avatarUrl = getAvatarUrl(user)
  const initials = displayName.slice(0, 2).toUpperCase()

  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-3 px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3">
          <a href="/" className="flex items-center gap-2.5" aria-label="HabitPulse home">
            <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-[0_0_24px_-4px] shadow-primary/60">
              <Activity className="size-4.5" strokeWidth={2.5} aria-hidden="true" />
            </span>
            <span className="text-base font-semibold tracking-tight">HabitPulse</span>
          </a>
          <span
            className="hidden items-center gap-1 rounded-full border border-flame/30 bg-flame/10 px-2.5 py-1 text-xs font-semibold text-flame sm:inline-flex"
            title="Your best active streak"
          >
            <Flame className="size-3.5 fill-flame" aria-hidden="true" />
            <span className="tabular-nums">{currentStreak}</span>
            <span className="font-medium text-flame/80">{t('dayStreak')}</span>
          </span>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          <Button
            variant="ghost"
            size="icon-lg"
            className="rounded-full"
            onClick={() => onRemindersChange(!remindersEnabled)}
            aria-label={remindersEnabled ? 'Turn off daily reminders' : 'Turn on daily reminders'}
            aria-pressed={remindersEnabled}
          >
            {remindersEnabled ? (
              <Bell className="text-primary" aria-hidden="true" />
            ) : (
              <BellOff aria-hidden="true" />
            )}
          </Button>
          <ThemeToggle />
          {isPro ? (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-pro/40 bg-pro/15 px-3 py-1 text-xs font-semibold text-pro">
              <Crown className="size-3.5" aria-hidden="true" />
              Pro
            </span>
          ) : (
            <Button
              onClick={onUpgrade}
              size="lg"
              className="bg-pro px-3 text-pro-foreground shadow-[0_0_24px_-6px] shadow-pro/70 hover:bg-pro/90"
            >
              <Sparkles data-icon="inline-start" aria-hidden="true" />
              <span className="hidden sm:inline">Upgrade to Pro</span>
              <span className="sm:hidden">Pro</span>
            </Button>
          )}

          <DropdownMenu>
            <DropdownMenuTrigger
              className="rounded-full outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label="Open profile menu"
            >
              <Avatar className="size-9 ring-1 ring-border">
                {avatarUrl && <AvatarImage src={avatarUrl} alt="" referrerPolicy="no-referrer" />}
                <AvatarFallback className="bg-secondary text-xs font-semibold text-foreground">
                  {initials}
                </AvatarFallback>
              </Avatar>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-60">
              <DropdownMenuGroup>
                <DropdownMenuLabel className="flex flex-col gap-0.5 py-2">
                  <span className="text-sm font-medium text-foreground">{displayName}</span>
                  <span className="truncate text-xs font-normal text-muted-foreground">
                    {user?.email ?? 'Sign in to sync your habits'}
                  </span>
                </DropdownMenuLabel>
              </DropdownMenuGroup>
              <DropdownMenuSeparator />
              <DropdownMenuGroup>
                <DropdownMenuItem render={<Link href="/settings" />}>
                  <Settings aria-hidden="true" />
                  {t('settings')}
                </DropdownMenuItem>
                {!user && (
                  <>
                    <DropdownMenuItem onClick={onSignIn}>
                      <LogIn aria-hidden="true" />
                      Sign in
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={onSignUp}>
                      <UserPlus aria-hidden="true" />
                      Create account
                    </DropdownMenuItem>
                  </>
                )}
                {!isPro && (
                  <DropdownMenuItem onClick={onUpgrade}>
                    <Sparkles className="text-pro" aria-hidden="true" />
                    Upgrade to Pro
                  </DropdownMenuItem>
                )}
              </DropdownMenuGroup>
              <DropdownMenuSeparator />
              <DropdownMenuGroup>
                <DropdownMenuLabel className="text-xs text-muted-foreground">Data</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => onExport('csv')}>
                  <FileSpreadsheet aria-hidden="true" />
                  Export as CSV
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onExport('json')}>
                  <FileJson aria-hidden="true" />
                  Export as JSON
                </DropdownMenuItem>
                <DropdownMenuItem
                  closeOnClick={false}
                  onClick={() => onRemindersChange(!remindersEnabled)}
                  className="justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Bell aria-hidden="true" />
                    {t('dailyReminders')}
                  </span>
                  <Switch checked={remindersEnabled} tabIndex={-1} aria-hidden="true" className="pointer-events-none" />
                </DropdownMenuItem>
              </DropdownMenuGroup>
              <DropdownMenuSeparator />
              <DropdownMenuGroup>
                <DropdownMenuItem variant="destructive" onClick={onSignOut} disabled={!user}>
                  <LogOut aria-hidden="true" />
                  Sign out
                </DropdownMenuItem>
              </DropdownMenuGroup>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}
