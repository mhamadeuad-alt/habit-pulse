'use client'

import { useState, type FormEvent } from 'react'
import { Dumbbell, Droplets, Moon, Plus, Sparkles, Timer, Wind } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import { useLocale } from '@/lib/i18n'

const TEMPLATES = [
  { key: 'workout', time: '07:30', icon: Dumbbell },
  { key: 'deepWork', time: '09:00', icon: Timer },
  { key: 'hydration', time: '14:00', icon: Droplets },
  { key: 'reading', time: '21:00', icon: Sparkles },
  { key: 'mindfulness', time: '08:15', icon: Wind },
  { key: 'digitalDetox', time: '22:30', icon: Moon },
] as const

interface AddHabitDialogProps { open: boolean; onOpenChange: (open: boolean) => void; onAdd: (name: string, targetTime: string) => void }

export function AddHabitDialog({ open, onOpenChange, onAdd }: AddHabitDialogProps) {
  const { t } = useLocale()
  const [name, setName] = useState('')
  const [time, setTime] = useState('07:00')
  function reset() { setName(''); setTime('07:00') }
  function handleSubmit(event: FormEvent<HTMLFormElement>) { event.preventDefault(); if (!name.trim()) return; onAdd(name, time); reset(); onOpenChange(false) }
  return <Dialog open={open} onOpenChange={(next) => { if (!next) reset(); onOpenChange(next) }}>
    <DialogContent className="gap-6 border-border bg-card p-6 sm:max-w-md">
      <DialogHeader><DialogTitle className="text-xl font-semibold tracking-tight">{t('addNewHabit')}</DialogTitle><DialogDescription>{t('addHabitDescription')}</DialogDescription></DialogHeader>
      <form onSubmit={handleSubmit} className="flex flex-col gap-5">
        <div className="flex flex-col gap-2"><Label htmlFor="habit-name">{t('habitName')}</Label><Input id="habit-name" value={name} onChange={(e) => setName(e.target.value)} placeholder={t('habitPlaceholder')} maxLength={80} required autoFocus className="h-10" /></div>
        <div className="flex flex-col gap-2"><Label htmlFor="habit-time">{t('targetTime')}</Label><Input id="habit-time" type="time" value={time} onChange={(e) => setTime(e.target.value)} className="h-10 [color-scheme:dark]" /></div>
        <div className="flex flex-col gap-2"><span className="text-xs font-medium text-muted-foreground">{t('globalTemplates')}</span><p className="text-xs text-muted-foreground">{t('globalTemplatesDescription')}</p><div className="grid grid-cols-2 gap-2">{TEMPLATES.map(({ key, time: templateTime, icon: Icon }) => { const label = t(key); return <button key={key} type="button" onClick={() => { setName(label); setTime(templateTime) }} className={cn('flex items-center gap-2 rounded-lg border px-3 py-2 text-start text-xs font-medium transition-colors', name === label ? 'border-primary/60 bg-primary/15 text-primary' : 'border-border bg-secondary/50 text-muted-foreground hover:border-primary/40 hover:text-foreground')}><Icon className="size-3.5 shrink-0" aria-hidden="true" />{label}</button> })}</div></div>
        <DialogFooter className="-mx-6 -mb-6 mt-1 border-t border-border bg-background/40 px-6 py-4"><Button type="button" variant="ghost" size="lg" onClick={() => onOpenChange(false)}>{t('cancel')}</Button><Button type="submit" size="lg" className="font-semibold" disabled={!name.trim()}><Plus data-icon="inline-start" aria-hidden="true" />{t('addHabit')}</Button></DialogFooter>
      </form>
    </DialogContent>
  </Dialog>
}
