import { Flame, Target, Trophy } from 'lucide-react'
import type { WeekDay } from '@/lib/habits'
import { cn } from '@/lib/utils'
import { useLocale } from '@/lib/i18n'

interface SummaryCardsProps {
  completionRate: number
  completed: number
  possible: number
  bestStreak: number
  bestStreakHabit: string | null
  perfectDays: number
  perfectDayMap: { day: WeekDay; perfect: boolean }[]
}

export function SummaryCards(props: SummaryCardsProps) {
  const { t, formatDate } = useLocale()
  return (
    <section aria-label={t('weeklyMatrix')} className="grid gap-4 md:grid-cols-3">
      <CompletionCard {...props} />
      <StreakCard {...props} />
      <PerfectDaysCard {...props} />
    </section>
  )
}

function CardShell({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn('relative overflow-hidden rounded-2xl border border-border bg-card p-5', className)}>
      {children}
    </div>
  )
}

function CardLabel({ icon: Icon, label, tone }: { icon: typeof Flame; label: string; tone: string }) {
  return (
    <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
      <span className={cn('flex size-7 items-center justify-center rounded-lg', tone)}>
        <Icon className="size-4" aria-hidden="true" />
      </span>
      {label}
    </div>
  )
}

function CompletionCard({ completionRate, completed, possible }: SummaryCardsProps) {
  const { t } = useLocale()
  const radius = 34
  const circumference = 2 * Math.PI * radius
  const offset = circumference * (1 - completionRate / 100)

  return (
    <CardShell className="flex items-center justify-between gap-4">
      <div className="flex flex-col gap-3">
        <CardLabel icon={Target} label={t('completionRate')} tone="bg-primary/15 text-primary" />
        <div className="flex flex-col">
          <span className="text-3xl font-semibold tracking-tight tabular-nums">{completionRate}%</span>
          <span className="text-sm text-muted-foreground tabular-nums">
            {completed} / {possible} {t('checkIns')}
          </span>
        </div>
      </div>
      <svg viewBox="0 0 80 80" className="size-20 shrink-0 -rotate-90" role="img" aria-label={`${completionRate}% complete`}>
        <circle cx="40" cy="40" r={radius} fill="none" stroke="var(--secondary)" strokeWidth="8" />
        <circle
          cx="40"
          cy="40"
          r={radius}
          fill="none"
          stroke="var(--primary)"
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="transition-[stroke-dashoffset] duration-700 ease-out"
        />
      </svg>
    </CardShell>
  )
}

function StreakCard({ bestStreak, bestStreakHabit }: SummaryCardsProps) {
  const { t } = useLocale()
  return (
    <CardShell>
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-12 -right-12 size-40 rounded-full bg-flame/20 blur-3xl"
      />
      <div className="relative flex flex-col gap-3">
        <CardLabel icon={Flame} label={t('bestStreak')} tone="bg-flame/15 text-flame" />
        <div className="flex flex-col">
          <span className="flex items-baseline gap-2">
            <Flame className="size-6 self-center fill-flame text-flame" aria-hidden="true" />
            <span className="text-3xl font-semibold tracking-tight tabular-nums">{bestStreak}</span>
            <span className="text-base font-medium text-muted-foreground">{t('days')}</span>
          </span>
          <span className="truncate text-sm text-muted-foreground">
            {bestStreakHabit ? `${t('leadingHabit')}: ${bestStreakHabit}` : t('startStreak')}
          </span>
        </div>
      </div>
    </CardShell>
  )
}

function PerfectDaysCard({ perfectDays, perfectDayMap }: SummaryCardsProps) {
  const { t, formatDate } = useLocale()
  return (
    <CardShell>
      <div className="flex flex-col gap-3">
        <CardLabel icon={Trophy} label={t('perfectDays')} tone="bg-primary/15 text-primary" />
        <div className="flex items-end justify-between gap-3">
          <div className="flex flex-col">
            <span className="text-3xl font-semibold tracking-tight tabular-nums">{perfectDays}</span>
            <span className="text-sm text-muted-foreground">{t('everyHabitDone')}</span>
          </div>
          <ol className="flex gap-1.5" aria-label="Perfect days this week">
            {perfectDayMap.map(({ day, perfect }) => (
              <li key={day.iso} className="flex flex-col items-center gap-1">
                <span
                  className={cn(
                    'size-3.5 rounded-full',
                    perfect
                      ? 'bg-primary shadow-[0_0_10px_-1px] shadow-primary'
                      : day.isFuture
                        ? 'border border-dashed border-border'
                        : 'bg-secondary',
                  )}
                />
                <span className="text-[10px] font-medium text-muted-foreground">
                  {formatDate(day.date, { weekday: 'short' }).charAt(0)}
                  <span className="sr-only">
                    {day.shortLabel} {perfect ? 'perfect' : 'not perfect'}
                  </span>
                </span>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </CardShell>
  )
}
