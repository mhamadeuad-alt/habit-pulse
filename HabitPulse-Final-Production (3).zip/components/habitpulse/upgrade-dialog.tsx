'use client'

import { useState } from 'react'
import { BarChart3, Check, Cloud, Infinity as InfinityIcon, Loader2, Lock, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { FREE_HABIT_LIMIT, PRO_PRICE_MONTHLY } from '@/lib/habits'

const FEATURES = [
  { icon: InfinityIcon, title: 'Unlimited habits', body: `Go beyond the ${FREE_HABIT_LIMIT}-habit Free limit.` },
  { icon: BarChart3, title: 'Advanced insights', body: '8-week trends, best days, and consistency scores.' },
  { icon: Cloud, title: 'Priority cloud sync', body: 'Real-time sync across every device you own.' },
]

interface UpgradeDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  reason?: string | null
  onCheckout: () => Promise<void>
}

export function UpgradeDialog({ open, onOpenChange, reason, onCheckout }: UpgradeDialogProps) {
  const [pending, setPending] = useState(false)

  async function handleCheckout() {
    setPending(true)
    try {
      await onCheckout()
    } finally {
      setPending(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="gap-0 overflow-hidden border-pro/30 bg-card p-0 sm:max-w-md">
        <div className="relative flex flex-col gap-3 bg-[radial-gradient(120%_100%_at_50%_0%,color-mix(in_oklab,var(--pro)_35%,transparent),transparent_70%)] px-6 pt-8 pb-6">
          <span className="flex size-11 items-center justify-center rounded-xl bg-pro text-pro-foreground shadow-[0_0_32px_-4px] shadow-pro">
            <Sparkles className="size-5" aria-hidden="true" />
          </span>
          <DialogHeader className="gap-1.5 text-left">
            <DialogTitle className="text-2xl font-semibold tracking-tight">HabitPulse Pro</DialogTitle>
            <DialogDescription className="text-pretty">
              {reason ?? 'Everything you need to turn good intentions into lasting routines.'}
            </DialogDescription>
          </DialogHeader>
          <p className="flex items-baseline gap-1">
            <span className="text-4xl font-semibold tracking-tight tabular-nums">${PRO_PRICE_MONTHLY}</span>
            <span className="text-sm text-muted-foreground">/ month · cancel anytime</span>
          </p>
        </div>

        <ul className="flex flex-col gap-4 border-t border-border px-6 py-5">
          {FEATURES.map(({ icon: Icon, title, body }) => (
            <li key={title} className="flex gap-3">
              <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-pro/15 text-pro">
                <Icon className="size-4" aria-hidden="true" />
              </span>
              <div className="flex flex-col">
                <span className="text-sm font-medium">{title}</span>
                <span className="text-sm text-muted-foreground">{body}</span>
              </div>
            </li>
          ))}
          <li className="flex items-center gap-2 text-sm text-muted-foreground">
            <Check className="size-4 text-primary" aria-hidden="true" />
            Includes everything in Free
          </li>
        </ul>

        <div className="flex flex-col gap-3 border-t border-border bg-background/40 px-6 py-5">
          <Button
            onClick={handleCheckout}
            disabled={pending}
            size="lg"
            className="h-11 bg-pro text-base font-semibold text-pro-foreground hover:bg-pro/90"
          >
            {pending ? (
              <Loader2 className="animate-spin" data-icon="inline-start" aria-hidden="true" />
            ) : (
              <Lock data-icon="inline-start" aria-hidden="true" />
            )}
            Continue to secure checkout
          </Button>
          <p className="text-center text-xs text-muted-foreground">Payments processed securely by Stripe.</p>
        </div>
      </DialogContent>
    </Dialog>
  )
}
