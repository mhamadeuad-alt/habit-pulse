'use client'

import { Fragment, useState } from 'react'
import { Check, ChevronLeft, ChevronRight, Clock, Flame, NotebookPen, Plus, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { formatTargetTime, type Habit, type WeekDay } from '@/lib/habits'
import { cn } from '@/lib/utils'
import { useLocale } from '@/lib/i18n'

export interface HabitRow {
  habit: Habit
  completedDays: Record<string, true>
  weekCount: number
  streak: number
  note: string
}

interface HabitMatrixProps {
  rows: HabitRow[]
  days: WeekDay[]
  weekKey: string
  rangeLabel: string
  isCurrentWeek: boolean
  habitLimitLabel: string | null
  onPrevWeek: () => void
  onNextWeek: () => void
  onThisWeek: () => void
  onAdd: () => void
  onToggle: (habitId: string, iso: string) => void
  onNoteChange: (habitId: string, text: string) => void
  onRemove: (habitId: string) => void
}

export function HabitMatrix({
  rows,
  days,
  weekKey,
  rangeLabel,
  isCurrentWeek,
  habitLimitLabel,
  onPrevWeek,
  onNextWeek,
  onThisWeek,
  onAdd,
  onToggle,
  onNoteChange,
  onRemove,
}: HabitMatrixProps) {
  const { t, formatDate, formatTime } = useLocale()
  const [openNotes, setOpenNotes] = useState<Record<string, boolean>>({})

  return (
    <section aria-labelledby="matrix-heading" className="overflow-hidden rounded-2xl border border-border bg-card">
      <div className="flex flex-col gap-4 border-b border-border p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-col gap-1">
          <h2 id="matrix-heading" className="text-lg font-semibold tracking-tight">
            {t('weeklyMatrix')}
          </h2>
          <p className="text-sm text-muted-foreground">
            {rangeLabel}
            {habitLimitLabel && <span className="text-pro"> · {habitLimitLabel}</span>}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center rounded-lg border border-border bg-background/50 p-0.5">
              <Button variant="ghost" size="icon-sm" onClick={onPrevWeek} aria-label={t('previousWeek')}>
              <ChevronLeft aria-hidden="true" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onThisWeek}
              disabled={isCurrentWeek}
              className="px-2 text-xs"
            >
              {t('thisWeek')}
            </Button>
            <Button variant="ghost" size="icon-sm" onClick={onNextWeek} aria-label={t('nextWeek')}>
              <ChevronRight aria-hidden="true" />
            </Button>
          </div>
          <Button onClick={onAdd} size="lg" className="font-semibold shadow-[0_0_20px_-6px] shadow-primary">
            <Plus data-icon="inline-start" aria-hidden="true" />
            {t('addHabit')}
          </Button>
        </div>
      </div>

      {rows.length === 0 ? (
        <div className="flex flex-col items-center gap-2 px-6 py-16 text-center">
          <p className="text-sm font-medium">{t('noHabits')}</p>
          <p className="max-w-xs text-sm text-pretty text-muted-foreground">
            {t('noHabitsDescription')}
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] border-collapse text-sm">
            <caption className="sr-only">Habit completion for {rangeLabel}</caption>
            <thead>
              <tr className="border-b border-border">
                <th scope="col" className="w-[34%] px-5 py-3 text-left text-xs font-medium text-muted-foreground">
                  {t('habit')}
                </th>
                {days.map((day) => (
                  <th
                    key={day.iso}
                    scope="col"
                    className={cn('px-1 py-3 text-center', day.isToday && 'bg-primary/[0.06]')}
                  >
                    <span className="flex flex-col items-center gap-0.5">
                      <span
                        className={cn(
                          'text-[11px] font-medium uppercase tracking-wide',
                          day.isToday ? 'text-primary' : 'text-muted-foreground',
                        )}
                      >
                        {formatDate(day.date, { weekday: 'short' })}
                      </span>
                      <span
                        className={cn(
                          'flex size-6 items-center justify-center rounded-full text-xs font-semibold tabular-nums',
                          day.isToday ? 'bg-primary text-primary-foreground' : 'text-foreground/80',
                        )}
                      >
                        {day.dayNumber}
                      </span>
                    </span>
                  </th>
                ))}
                <th scope="col" className="px-3 py-3 text-center text-xs font-medium text-muted-foreground">
                  {t('streak')}
                </th>
                <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-muted-foreground">
                  {t('week')}
                </th>
                <th scope="col" className="w-20 px-3 py-3">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => {
                const notesOpen = Boolean(openNotes[row.habit.id])
                const hasNote = row.note.trim().length > 0
                const progress = Math.round((row.weekCount / days.length) * 100)
                return (
                  <Fragment key={row.habit.id}>
                    <tr className={cn('group border-b border-border/70', notesOpen && 'border-b-0')}>
                      <th scope="row" className="px-5 py-3.5 text-left font-normal">
                        <div className="flex flex-col gap-1">
                          <span className="font-medium text-foreground">{row.habit.name}</span>
                          {row.habit.targetTime && (
                            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                              <Clock className="size-3" aria-hidden="true" />
                              {formatTime(row.habit.targetTime)}
                            </span>
                          )}
                        </div>
                      </th>
                      {days.map((day) => (
                        <td key={day.iso} className={cn('px-1 py-3.5 text-center', day.isToday && 'bg-primary/[0.06]')}>
                          <HabitCheck
                            checked={Boolean(row.completedDays[day.iso])}
                            isToday={day.isToday}
                            isFuture={day.isFuture}
                            label={`${row.habit.name} — ${formatDate(day.date, { weekday: 'long', month: 'short', day: 'numeric' })}`}
                            onToggle={() => onToggle(row.habit.id, day.iso)}
                          />
                        </td>
                      ))}
                      <td className="px-3 py-3.5 text-center">
                        <span
                          className={cn(
                            'inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold tabular-nums',
                            row.streak > 0 ? 'bg-flame/15 text-flame' : 'bg-secondary text-muted-foreground',
                          )}
                        >
                          <Flame className={cn('size-3.5', row.streak > 0 && 'fill-flame')} aria-hidden="true" />
                          {row.streak}
                          <span className="sr-only">{t('dayStreak')}</span>
                        </span>
                      </td>
                      <td className="px-3 py-3.5">
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-14 overflow-hidden rounded-full bg-secondary" aria-hidden="true">
                            <div
                              className="h-full rounded-full bg-primary transition-[width] duration-500"
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                          <span className="text-xs text-muted-foreground tabular-nums">
                            {row.weekCount}/{days.length}
                          </span>
                        </div>
                      </td>
                      <td className="px-3 py-3.5">
                        <div className="flex items-center justify-end gap-0.5">
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            aria-expanded={notesOpen}
                            aria-label={`${notesOpen ? 'Hide' : 'Show'} notes for ${row.habit.name}`}
                            onClick={() => setOpenNotes((s) => ({ ...s, [row.habit.id]: !notesOpen }))}
                            className={cn(hasNote ? 'text-primary' : 'text-muted-foreground')}
                          >
                            <NotebookPen aria-hidden="true" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            aria-label={`Delete ${row.habit.name}`}
                            onClick={() => onRemove(row.habit.id)}
                            className="text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100 hover:text-destructive focus-visible:opacity-100"
                          >
                            <Trash2 aria-hidden="true" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                    {notesOpen && (
                      <tr className="border-b border-border/70">
                        <td colSpan={days.length + 4} className="px-5 pb-4">
                          <NoteEditor
                            key={`${weekKey}-${row.habit.id}`}
                            habitName={row.habit.name}
                            initialValue={row.note}
                            onCommit={(text) => onNoteChange(row.habit.id, text)}
                          />
                        </td>
                      </tr>
                    )}
                  </Fragment>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  )
}

function HabitCheck({
  checked,
  isToday,
  isFuture,
  label,
  onToggle,
}: {
  checked: boolean
  isToday: boolean
  isFuture: boolean
  label: string
  onToggle: () => void
}) {
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={checked}
      aria-label={label}
      onClick={onToggle}
      className={cn(
        'relative inline-flex size-9 items-center justify-center rounded-lg border transition-all outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-card',
        checked
          ? 'border-primary bg-primary text-primary-foreground shadow-[0_0_16px_-4px] shadow-primary'
          : 'border-input bg-background/40 text-transparent hover:border-primary/60 hover:bg-primary/10',
        isToday && !checked && 'border-primary/50',
        isFuture && !checked && 'border-dashed',
      )}
    >
      {checked && (
        <>
          <span className="absolute inset-0 animate-check-ring rounded-lg bg-primary/40" aria-hidden="true" />
          <Check className="relative size-4.5 animate-check-pop" strokeWidth={3} aria-hidden="true" />
        </>
      )}
    </button>
  )
}

function NoteEditor({
  habitName,
  initialValue,
  onCommit,
}: {
  habitName: string
  initialValue: string
  onCommit: (text: string) => void
}) {
  const [draft, setDraft] = useState(initialValue)
  const id = `note-${habitName.replace(/\W+/g, '-').toLowerCase()}`
  return (
    <div className="flex flex-col gap-2 rounded-xl border border-border bg-background/40 p-3">
      <label htmlFor={id} className="text-xs font-medium text-muted-foreground">
        Side notes for {habitName} this week
      </label>
      <Textarea
        id={id}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={() => draft !== initialValue && onCommit(draft)}
        placeholder="What helped? What got in the way?"
        maxLength={4000}
        rows={2}
        className="min-h-16 resize-y border-input bg-card"
      />
    </div>
  )
}
