'use client'

import { useState } from 'react'
import { Crown, Lock, MessageCircle, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

interface ProInsightsProps {
  isPro: boolean
  authToken: string | null
  trend: { label: string; rate: number }[]
  mostConsistent: string | null
  bestWeekday: string | null
  onUpgrade: () => void
}

export function ProInsights({ isPro, authToken, trend, mostConsistent, bestWeekday, onUpgrade }: ProInsightsProps) {
  const [coach, setCoach] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const average = trend.length ? Math.round(trend.reduce((s, t) => s + t.rate, 0) / trend.length) : 0

  async function askCoach() {
    if (!authToken) { toast.error('Sign in to use AI Coach.'); return }
    setLoading(true)
    try {
      const headers: Record<string, string> = { 'content-type': 'application/json' }
      if (authToken) headers.authorization = `Bearer ${authToken}`
      const response = await fetch('/api/coach', { method: 'POST', headers, body: JSON.stringify({ completionRate: average, bestWeekday, habits: mostConsistent ? [{ name: mostConsistent, streak: 0, completionRate: average }] : [] }) })
      const data = (await response.json().catch(() => ({}))) as { insight?: string; error?: string }
      if (!response.ok) throw new Error(data.error ?? 'AI Coach is unavailable.')
      setCoach(data.insight ?? null)
    } catch (error) { toast.error(error instanceof Error ? error.message : 'AI Coach is unavailable.') } finally { setLoading(false) }
  }

  return <section aria-labelledby="insights-heading" className="relative flex flex-col gap-4 overflow-hidden rounded-2xl border border-pro/30 bg-card p-5">
    <div aria-hidden="true" className="pointer-events-none absolute -top-20 -right-16 size-56 rounded-full bg-pro/20 blur-3xl" />
    <div className="relative flex items-center justify-between gap-3"><div className="flex items-center gap-2.5"><span className="flex size-8 items-center justify-center rounded-lg bg-pro/15 text-pro"><Sparkles className="size-4" aria-hidden="true" /></span><div className="flex flex-col"><h2 id="insights-heading" className="text-base font-semibold tracking-tight">Pro insights</h2><p className="text-xs text-muted-foreground">8-week consistency trend</p></div></div><span className="inline-flex items-center gap-1 rounded-full bg-pro/15 px-2 py-0.5 text-[11px] font-semibold text-pro"><Crown className="size-3" aria-hidden="true" />PRO</span></div>
    <div className={cn('relative flex flex-col gap-4', !isPro && 'pointer-events-none blur-[5px] select-none')} aria-hidden={!isPro}><div className="flex h-28 items-end gap-2">{trend.map((week, i) => <div key={week.label} className="flex flex-1 flex-col items-center gap-1.5"><div className="flex h-24 w-full items-end overflow-hidden rounded-md bg-secondary/60"><div className={cn('w-full rounded-md', i === trend.length - 1 ? 'bg-pro' : 'bg-pro/45')} style={{ height: `${Math.max(week.rate, 4)}%` }} /></div><span className="text-[10px] text-muted-foreground">{week.label}</span></div>)}</div><dl className="grid grid-cols-3 gap-3 border-t border-border pt-4"><Stat label="8-wk average" value={`${average}%`} /><Stat label="Most consistent" value={mostConsistent ?? '—'} /><Stat label="Best day" value={bestWeekday ?? '—'} /></dl></div>
    {isPro && <div className="relative flex flex-col gap-2 border-t border-border pt-4"><Button variant="outline" size="sm" onClick={() => void askCoach()} disabled={loading}><MessageCircle data-icon="inline-start" />{loading ? 'Thinking…' : 'Ask AI Coach'}</Button>{coach && <p className="rounded-lg border border-pro/25 bg-pro/10 p-3 text-sm leading-relaxed text-foreground/90">{coach}</p>}</div>}
    {!isPro && <div className="absolute inset-x-0 bottom-0 top-16 flex flex-col items-center justify-center gap-3 bg-card/40 px-6 text-center"><span className="flex size-10 items-center justify-center rounded-full bg-pro/20 text-pro ring-1 ring-pro/40"><Lock className="size-4" aria-hidden="true" /></span><p className="max-w-56 text-sm text-pretty text-foreground/90">See long-term trends, your strongest habit, and your best day.</p><Button onClick={onUpgrade} size="lg" className="bg-pro font-semibold text-pro-foreground hover:bg-pro/90">Unlock with Pro</Button></div>}
  </section>
}

function Stat({ label, value }: { label: string; value: string }) { return <div className="flex min-w-0 flex-col gap-0.5"><dt className="text-[11px] text-muted-foreground">{label}</dt><dd className="truncate text-sm font-semibold">{value}</dd></div> }
