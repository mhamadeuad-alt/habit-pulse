'use client'

import { useState, type FormEvent } from 'react'
import { Activity, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import type { SupabaseClient } from '@supabase/supabase-js'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { authRedirectUrl, signInWithGoogle } from '@/lib/auth'
import { cn } from '@/lib/utils'
import { GoogleIcon } from './google-icon'

export type AuthView = 'sign-in' | 'sign-up' | 'forgot'

interface AuthDialogProps {
  view: AuthView | null
  onViewChange: (view: AuthView | null) => void
  supabase: SupabaseClient | null
  /** Where to land after Google / email-link flows. Defaults to the dashboard. */
  next?: string
}

export function AuthDialog({ view, onViewChange, supabase, next = '/' }: AuthDialogProps) {
  const [pending, setPending] = useState(false)
  const [googlePending, setGooglePending] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const isSignUp = view === 'sign-up'
  const isForgot = view === 'forgot'

  function switchView(target: AuthView) {
    setError(null)
    onViewChange(target)
  }

  async function handleGoogle() {
    setGooglePending(true)
    setError(null)
    if (!supabase) {
      setError('Authentication is unavailable until Supabase is configured.')
      setGooglePending(false)
      return
    }
    const message = await signInWithGoogle(supabase, next)
    if (message) {
      setError(message)
      setGooglePending(false)
      return
    }
    // In an iframe the flow opens in a new tab and this page stays put.
    setTimeout(() => setGooglePending(false), 4000)
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const email = String(form.get('email') ?? '').trim()
    const password = String(form.get('password') ?? '')
    const fullName = String(form.get('name') ?? '').trim()

    if (!supabase) {
      setError('Authentication is unavailable until Supabase is configured.')
      return
    }

    setPending(true)
    setError(null)

    if (isForgot) {
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: authRedirectUrl('/settings?tab=security&recovery=1'),
      })
      setPending(false)
      if (resetError) {
        setError(resetError.message)
        return
      }
      // Same message whether or not the account exists, so emails can't be enumerated.
      toast.success('If that email has an account, a reset link is on its way.')
      onViewChange('sign-in')
      return
    }

    const result = isSignUp
      ? await supabase.auth.signUp({
          email,
          password,
          options: { data: { full_name: fullName }, emailRedirectTo: authRedirectUrl(next) },
        })
      : await supabase.auth.signInWithPassword({ email, password })
    setPending(false)

    if (result.error) {
      setError(result.error.message)
      return
    }
    if (isSignUp && !result.data.session) {
      toast.success('Check your inbox to confirm your email.')
    } else {
      toast.success(isSignUp ? 'Welcome to HabitPulse!' : 'Welcome back.')
    }
    onViewChange(null)
  }

  const title = isForgot ? 'Reset your password' : isSignUp ? 'Create your account' : 'Welcome back'
  const description = isForgot
    ? 'Enter your email and we’ll send you a reset link.'
    : isSignUp
      ? 'Sync your habits across every device.'
      : 'Sign in to pick up your streaks.'

  return (
    <Dialog open={view !== null} onOpenChange={(open) => !open && onViewChange(null)}>
      <DialogContent className="gap-6 border-border bg-card p-6 sm:max-w-md">
        <DialogHeader className="items-center gap-3 text-center">
          <span className="flex size-11 items-center justify-center rounded-xl bg-primary/15 text-primary ring-1 ring-primary/30">
            <Activity className="size-5" strokeWidth={2.5} aria-hidden="true" />
          </span>
          <DialogTitle className="text-xl font-semibold tracking-tight">{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        {!isForgot && (
          <div className="grid grid-cols-2 rounded-lg bg-secondary p-1" role="tablist" aria-label="Authentication">
            {(['sign-in', 'sign-up'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                role="tab"
                aria-selected={view === tab}
                onClick={() => switchView(tab)}
                className={cn(
                  'rounded-md py-1.5 text-sm font-medium transition-colors',
                  view === tab ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {tab === 'sign-in' ? 'Sign in' : 'Sign up'}
              </button>
            ))}
          </div>
        )}

        {!isForgot && (
          <>
            <Button
              type="button"
              variant="outline"
              size="lg"
              className="h-10 gap-2.5 font-medium"
              onClick={handleGoogle}
              disabled={googlePending || pending}
            >
              {googlePending ? (
                <Loader2 className="animate-spin" aria-hidden="true" />
              ) : (
                <GoogleIcon className="size-4" />
              )}
              Continue with Google
            </Button>

            <div className="flex items-center gap-3 text-xs text-muted-foreground" role="separator">
              <span className="h-px flex-1 bg-border" />
              or use email
              <span className="h-px flex-1 bg-border" />
            </div>
          </>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {isSignUp && (
            <div className="flex flex-col gap-2">
              <Label htmlFor="auth-name">Name</Label>
              <Input id="auth-name" name="name" autoComplete="name" placeholder="Alex Rivera" />
            </div>
          )}
          <div className="flex flex-col gap-2">
            <Label htmlFor="auth-email">Email</Label>
            <Input
              id="auth-email"
              name="email"
              type="email"
              required
              autoComplete="email"
              placeholder="you@example.com"
            />
          </div>
          {!isForgot && (
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="auth-password">Password</Label>
                {!isSignUp && (
                  <button
                    type="button"
                    onClick={() => switchView('forgot')}
                    className="text-xs text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <Input
                id="auth-password"
                name="password"
                type="password"
                required
                minLength={8}
                autoComplete={isSignUp ? 'new-password' : 'current-password'}
                placeholder="At least 8 characters"
              />
            </div>
          )}

          {error && (
            <p role="alert" className="text-sm text-destructive">
              {error}
            </p>
          )}

          <Button type="submit" size="lg" className="h-10 font-semibold" disabled={pending}>
            {pending && <Loader2 className="animate-spin" data-icon="inline-start" aria-hidden="true" />}
            {isForgot ? 'Send reset link' : isSignUp ? 'Create account' : 'Sign in'}
          </Button>

          {isForgot && (
            <button
              type="button"
              onClick={() => switchView('sign-in')}
              className="text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
            >
              Back to sign in
            </button>
          )}
        </form>
      </DialogContent>
    </Dialog>
  )
}
