'use client'

import { useMemo, useState } from 'react'
import { Area, Bar, CartesianGrid, ComposedChart, XAxis, YAxis } from 'recharts'
import { BarChart3, Flame, TrendingDown, TrendingUp, Trophy } from 'lucide-react'
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart'
import { getBestStreak, getDailySeries, getStreak, toISODate, addDays, startOfDay, type DailyPoint, type HabitState } from '@/lib/habits'
import { cn } from '@/lib/utils'

const RANGES = [14, 30, 90] as const
type Range = (typeof RANGES)[number]

const chartConfig = {
  rate: { label: 'Daily completion', color: 'var(--chart-4)' },
  rolling: { label: '7-day average', color: 'var(--primary)' },
} satisfies ChartConfig

interface StreakAnalyticsProps {
  state: HabitState
  today: Date
}

export function StreakAnalytics({ state, today }: StreakAnalyticsProps) {
  const [range, setRange] = useState<Range>(30)
  const [habitId, setHabitId] = useState<string | null>(null)
  const selected = habitId && state.habits.some((h) => h.id === habitId) ? habitId : null
  const selectedHabit = selected ? state.habits.find((habit) => habit.id === selected) ?? null : null

  const series = useMemo<DailyPoint[]>(() => {
    if (!selectedHabit) return getDailySeries(state, today, range)

    // A selected habit is never aggregated with the rest of the account. Each
    // bar is deliberately binary: 100 when this habit is checked, otherwise 0.
    const completions = state.completions[selectedHabit.id] ?? {}
    const end = startOfDay(today)
    const points = Array.from({ length: range }, (_, index) => {
      const date = addDays(end, -(range - 1 - index))
      const iso = toISODate(date)
      const done = completions[iso] ? 1 : 0
      return { date, iso, done, total: 1 }
    })

    return points.map((point, index) => {
      const window = points.slice(Math.max(0, index - 6), index + 1)
      const rollingDone = window.reduce((sum, day) => sum + day.done, 0)
      return {
        iso: point.iso,
        label: point.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        done: point.done,
        total: 1,
        rate: point.done * 100,
        rolling: Math.round((rollingDone / window.length) * 100),
      }
    })
  }, [state, today, range, selectedHabit])

  const leaderboard = useMemo(() => {
    const windowIsos = Array.from({ length: range }, (_, i) => toISODate(addDays(today, -i)))
    return state.habits
      .map((habit) => {
        const days = state.completions[habit.id]
        const done = windowIsos.filter((iso) => days?.[iso]).length
        return {
          habit,
          current: getStreak(days, today),
          best: getBestStreak(days, today),
          rate: Math.round((done / range) * 100),
        }
      })
      .sort((a, b) => b.current - a.current || b.best - a.best)
  }, [state, today, range])

  const average = series.length ? Math.round(series.reduce((s, p) => s + p.rate, 0) / series.length) : 0
  const recent = series.slice(-7)
  const prior = series.slice(-14, -7)
  const avg = (pts: typeof series) => (pts.length ? pts.reduce((s, p) => s + p.rate, 0) / pts.length : 0)
  const delta = Math.round(avg(recent) - avg(prior))
  const selectedName = selectedHabit?.name

  return (
    <section aria-labelledby="analytics-heading" className="flex flex-col gap-5 rounded-2xl border border-border bg-card p-4 sm:p-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex items-center gap-2.5">
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary/15 text-primary">
            <BarChart3 className="size-4" aria-hidden="true" />
          </span>
          <div className="flex flex-col">
            <h2 id="analytics-heading" className="text-base font-semibold tracking-tight">
              Streaks &amp; analytics
            </h2>
            <p className="text-xs text-muted-foreground">
              {selectedName ? `${selectedName} · last ${range} days` : `All habits · last ${range} days`}
            </p>
          </div>
        </div>

        <div role="group" aria-label="Date range" className="inline-flex self-start rounded-lg border border-border bg-secondary/50 p-0.5">
          {RANGES.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRange(r)}
              aria-pressed={range === r}
              className={cn(
                'rounded-md px-3 py-1 text-xs font-medium transition-colors focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none',
                range === r ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {r}d
            </button>
          ))}
        </div>
      </div>

      <dl className="grid grid-cols-3 gap-3">
        <Metric label="Avg completion" value={`${average}%`} />
        <Metric
          label="vs. prior week"
          value={`${delta > 0 ? '+' : ''}${delta}%`}
          tone={delta > 0 ? 'text-primary' : delta < 0 ? 'text-destructive' : undefined}
          icon={delta >= 0 ? TrendingUp : TrendingDown}
        />
        <Metric label="Perfect days" value={String(series.filter((p) => p.total > 0 && p.done === p.total).length)} />
      </dl>

      {state.habits.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border py-10 text-center text-sm text-muted-foreground">
          Add a habit to see your completion graph.
        </p>
      ) : (
        <ChartContainer config={chartConfig} className="aspect-auto h-52 w-full sm:h-60">
          <ComposedChart
            key={`${selected ?? 'all'}-${range}`}
            data={series}
            margin={{ left: 0, right: 4, top: 8 }}
          >
            <defs>
              <linearGradient id="fill-rolling" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--color-rolling)" stopOpacity={0.35} />
                <stop offset="95%" stopColor="var(--color-rolling)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} strokeDasharray="3 3" />
            <XAxis dataKey="label" tickLine={false} axisLine={false} tickMargin={8} minTickGap={24} />
            <YAxis domain={[0, 100]} tickLine={false} axisLine={false} tickFormatter={(v) => `${v}%`} width={40} ticks={[0, 50, 100]} />
            <ChartTooltip
              cursor={false}
              content={<ChartTooltipContent indicator="dot" formatter={(value, name) => (
                <div className="flex w-full items-center justify-between gap-4">
                  <span className="text-muted-foreground">{chartConfig[name as keyof typeof chartConfig]?.label}</span>
                  <span className="font-mono font-medium tabular-nums">{value}%</span>
                </div>
              )} />}
            />
            <Bar
              dataKey="rate"
              fill="var(--color-rate)"
              fillOpacity={0.35}
              radius={[3, 3, 0, 0]}
              maxBarSize={14}
              // Keep 0% as the data value, but leave a 2px baseline marker so
              // unchecked days remain visibly represented in the chart.
              minPointSize={2}
              isAnimationActive={false}
            />
            <Area dataKey="rolling" type="monotone" stroke="var(--color-rolling)" strokeWidth={2} fill="url(#fill-rolling)" />
          </ComposedChart>
        </ChartContainer>
      )}

      {leaderboard.length > 0 && (
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium">Streak counters</h3>
            {selected && (
              <button
                type="button"
                onClick={() => setHabitId(null)}
                className="text-xs font-medium text-primary hover:underline"
              >
                Show all habits
              </button>
            )}
          </div>
          <ul className="grid gap-2 sm:grid-cols-2">
            {leaderboard.map(({ habit, current, best, rate }) => {
              const isSelected = selected === habit.id
              return (
                <li key={habit.id}>
                  <button
                    type="button"
                    onClick={() => setHabitId(isSelected ? null : habit.id)}
                    aria-pressed={isSelected}
                    className={cn(
                      'flex w-full flex-col gap-2 rounded-xl border p-3 text-left transition-colors focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none',
                      isSelected ? 'border-primary/60 bg-primary/10' : 'border-border bg-secondary/30 hover:bg-secondary/60',
                    )}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-sm font-medium">{habit.name}</span>
                      <span className="inline-flex shrink-0 items-center gap-1 text-sm font-semibold text-flame tabular-nums">
                        <Flame className={cn('size-3.5', current > 0 && 'fill-flame')} aria-hidden="true" />
                        {current}
                        <span className="sr-only">day current streak</span>
                      </span>
                    </div>
                    <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                      <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${rate}%` }} />
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                      <span className="tabular-nums">{rate}% in {range}d</span>
                      <span className="inline-flex items-center gap-1 tabular-nums">
                        <Trophy className="size-3" aria-hidden="true" />
                        Best {best}d
                      </span>
                    </div>
                  </button>
                </li>
              )
            })}
          </ul>
        </div>
      )}
    </section>
  )
}

function Metric({
  label,
  value,
  tone,
  icon: Icon,
}: {
  label: string
  value: string
  tone?: string
  icon?: typeof TrendingUp
}) {
  return (
    <div className="flex min-w-0 flex-col gap-0.5 rounded-xl bg-secondary/40 px-3 py-2.5">
      <dt className="truncate text-[11px] text-muted-foreground">{label}</dt>
      <dd className={cn('inline-flex items-center gap-1 text-lg font-semibold tabular-nums', tone)}>
        {Icon && <Icon className="size-4" aria-hidden="true" />}
        {value}
      </dd>
    </div>
  )
}
