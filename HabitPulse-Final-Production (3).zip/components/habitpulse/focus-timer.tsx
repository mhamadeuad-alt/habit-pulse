'use client'

import { useEffect, useState } from 'react'
import { Check, Pause, Play, RotateCcw, Timer, Volume2 } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useLocale } from '@/lib/i18n'

const STORAGE_KEY = 'habitpulse:focus-timer:v2'
const DEFAULT_DURATION_SECONDS = 25 * 60

type Part = 'hours' | 'minutes' | 'seconds'
type TimerSound = 'digital-chime' | 'success-bell' | 'classic-alarm' | 'gentle-gong'

const TIMER_SOUNDS: readonly TimerSound[] = ['digital-chime', 'success-bell', 'classic-alarm', 'gentle-gong']

function isTimerSound(value: unknown): value is TimerSound {
  return typeof value === 'string' && TIMER_SOUNDS.includes(value as TimerSound)
}

function splitDuration(totalSeconds: number) {
  return {
    hours: Math.floor(totalSeconds / 3600),
    minutes: Math.floor((totalSeconds % 3600) / 60),
    seconds: totalSeconds % 60,
  }
}

function clampPart(part: Part, value: number) {
  const max = part === 'hours' ? 99 : 59
  return Math.max(0, Math.min(max, Number.isFinite(value) ? value : 0))
}

function playTimerSound(sound: TimerSound) {
  if (typeof window === 'undefined') return
  const AudioContextClass = window.AudioContext ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
  if (!AudioContextClass) return

  const context = new AudioContextClass()
  const now = context.currentTime
  const master = context.createGain()
  master.gain.setValueAtTime(0.0001, now)
  master.gain.exponentialRampToValueAtTime(0.18, now + 0.02)
  master.gain.exponentialRampToValueAtTime(0.0001, now + 1.5)
  master.connect(context.destination)

  const tone = (frequency: number, start: number, duration: number, type: OscillatorType, level = 0.7) => {
    const oscillator = context.createOscillator()
    const gain = context.createGain()
    oscillator.type = type
    oscillator.frequency.setValueAtTime(frequency, now + start)
    gain.gain.setValueAtTime(0.0001, now + start)
    gain.gain.exponentialRampToValueAtTime(level, now + start + 0.015)
    gain.gain.exponentialRampToValueAtTime(0.0001, now + start + duration)
    oscillator.connect(gain)
    gain.connect(master)
    oscillator.start(now + start)
    oscillator.stop(now + start + duration + 0.04)
  }

  switch (sound) {
    case 'success-bell':
      tone(523.25, 0, 0.42, 'sine')
      tone(659.25, 0.16, 0.46, 'sine')
      tone(783.99, 0.32, 0.7, 'sine')
      break
    case 'classic-alarm':
      tone(880, 0, 0.16, 'square', 0.55)
      tone(880, 0.3, 0.16, 'square', 0.55)
      break
    case 'gentle-gong':
      tone(196, 0, 1.45, 'sine', 0.8)
      tone(293.66, 0.03, 1.2, 'sine', 0.35)
      break
    case 'digital-chime':
    default:
      tone(880, 0, 0.45, 'sine')
      tone(1318.51, 0.16, 0.75, 'sine', 0.55)
      break
  }

  void context.resume()
  window.setTimeout(() => void context.close(), 1800)
}

export function FocusTimer() {
  const { t } = useLocale()
  const initial = splitDuration(DEFAULT_DURATION_SECONDS)
  const [durationSeconds, setDurationSeconds] = useState(DEFAULT_DURATION_SECONDS)
  const [remaining, setRemaining] = useState(DEFAULT_DURATION_SECONDS)
  const [hours, setHours] = useState(initial.hours)
  const [minutesInput, setMinutesInput] = useState(initial.minutes)
  const [secondsInput, setSecondsInput] = useState(initial.seconds)
  const [completedSessions, setCompletedSessions] = useState(0)
  const [totalFocusedSeconds, setTotalFocusedSeconds] = useState(0)
  const [storageHydrated, setStorageHydrated] = useState(false)
  const [sound, setSound] = useState<TimerSound>('digital-chime')
  const [running, setRunning] = useState(false)
  const [finished, setFinished] = useState(false)

  useEffect(() => {
    try {
      const saved = JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? 'null') as {
        durationSeconds?: number
        duration?: number
        remaining?: number
        completedSessions?: number
        totalFocusedSeconds?: number
        sound?: unknown
      } | null
      const storedDuration = saved?.durationSeconds ?? (saved?.duration ? saved.duration * 60 : DEFAULT_DURATION_SECONDS)
      if (Number.isFinite(storedDuration) && storedDuration > 0) {
        const nextDuration = Math.round(storedDuration)
        const next = splitDuration(nextDuration)
        setDurationSeconds(nextDuration)
        setRemaining(Math.min(Math.max(1, saved?.remaining ?? nextDuration), nextDuration))
        setHours(next.hours)
        setMinutesInput(next.minutes)
        setSecondsInput(next.seconds)
      }
      if (Number.isFinite(saved?.completedSessions) && (saved?.completedSessions ?? 0) >= 0) {
        setCompletedSessions(Math.floor(saved?.completedSessions ?? 0))
      }
      if (Number.isFinite(saved?.totalFocusedSeconds) && (saved?.totalFocusedSeconds ?? 0) >= 0) {
        setTotalFocusedSeconds(Math.floor(saved?.totalFocusedSeconds ?? 0))
      }
      if (isTimerSound(saved?.sound)) setSound(saved.sound)
    } catch {
      // Use the default settings when local storage is unavailable or corrupt.
    } finally {
      setStorageHydrated(true)
    }
  }, [])

  useEffect(() => {
    if (!storageHydrated) return
    try {
      window.localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ durationSeconds, remaining, completedSessions, totalFocusedSeconds, sound, running: false }),
      )
    } catch {
      // Storage is optional; the timer still works for this session.
    }
  }, [durationSeconds, remaining, completedSessions, totalFocusedSeconds, sound, storageHydrated])

  useEffect(() => {
    if (!running) return
    const timer = window.setInterval(() => {
      setRemaining((value) => {
        if (value <= 1) {
          window.clearInterval(timer)
          setRunning(false)
          setFinished(true)
          setCompletedSessions((value) => value + 1)
          setTotalFocusedSeconds((value) => value + durationSeconds)
          playTimerSound(sound)
          return 0
        }
        return value - 1
      })
    }, 1000)
    return () => window.clearInterval(timer)
  }, [running, durationSeconds, sound])

  const displayHours = Math.floor(remaining / 3600)
  const displayMinutes = Math.floor((remaining % 3600) / 60)
  const displaySeconds = remaining % 60
  const display = `${displayHours > 0 ? `${displayHours.toString().padStart(2, '0')}:` : ''}${displayMinutes
    .toString()
    .padStart(2, '0')}:${displaySeconds.toString().padStart(2, '0')}`
  const progress = durationSeconds > 0 ? ((durationSeconds - remaining) / durationSeconds) * 100 : 0
  const totalFocusedMinutes = Math.floor(totalFocusedSeconds / 60)

  function updatePart(part: Part, raw: string) {
    const value = clampPart(part, Number(raw))
    const next = { hours, minutes: minutesInput, seconds: secondsInput, [part]: value }
    const nextDuration = Math.max(1, next.hours * 3600 + next.minutes * 60 + next.seconds)
    setHours(next.hours)
    setMinutesInput(next.minutes)
    setSecondsInput(next.seconds)
    setDurationSeconds(nextDuration)
    setRemaining(nextDuration)
    setFinished(false)
    setRunning(false)
  }

  function reset() {
    setRemaining(durationSeconds)
    setFinished(false)
    setRunning(false)
  }

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2">
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary/15 text-primary">
            <Timer className="size-4" aria-hidden="true" />
          </span>
          {t('focusTimer')}
        </CardTitle>
        <CardDescription>{t('focusTimerDescription')}</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div className="flex flex-wrap items-end gap-2" aria-label={t('customDuration')}>
            {(
              [
                ['hours', hours, t('hours'), 99],
                ['minutes', minutesInput, t('minutes'), 59],
                ['seconds', secondsInput, t('seconds'), 59],
              ] as const
            ).map(([part, value, label, max]) => (
              <label key={part} className="flex w-20 flex-col gap-1 text-[11px] font-medium text-muted-foreground">
                <span>{label}</span>
                <Input
                  type="number"
                  min={0}
                  max={max}
                  step={1}
                  value={value}
                  onChange={(event) => updatePart(part, event.target.value)}
                  disabled={running}
                  aria-label={`${t('customDuration')} ${label}`}
                  className="h-9 text-center font-mono tabular-nums"
                />
              </label>
            ))}
          </div>
          <span className="text-xs text-muted-foreground">
            {finished ? t('focusFinished') : running ? t('focusRunning') : t('focusReady')}
          </span>
        </div>

        <div className="flex flex-wrap items-end gap-3 rounded-lg border border-border/70 bg-secondary/30 p-3">
          <label className="flex min-w-44 flex-1 flex-col gap-1 text-xs font-medium text-muted-foreground">
            <span className="inline-flex items-center gap-1.5"><Volume2 className="size-3.5" aria-hidden="true" />{t('timerSound')}</span>
            <select
              value={sound}
              disabled={running}
              onChange={(event) => setSound(event.target.value as TimerSound)}
              aria-label={t('timerSound')}
              className="h-9 rounded-md border border-input bg-background px-3 text-sm font-normal text-foreground outline-none transition-colors focus:ring-2 focus:ring-ring"
            >
              <option value="digital-chime">{t('digitalChime')}</option>
              <option value="success-bell">{t('successBell')}</option>
              <option value="classic-alarm">{t('classicAlarm')}</option>
              <option value="gentle-gong">{t('gentleGong')}</option>
            </select>
          </label>
          <Button type="button" variant="outline" size="sm" disabled={running} onClick={() => playTimerSound(sound)}>
            <Volume2 data-icon="inline-start" />
            {t('playTestSound')}
          </Button>
        </div>

        <p className="text-xs text-muted-foreground" aria-live="polite">
          {completedSessions} {t('focusSessions')} · {totalFocusedMinutes} {t('focusMinutes')}
        </p>

        <div className="relative overflow-hidden rounded-xl border border-border bg-background/40 p-5">
          <div className="absolute inset-y-0 start-0 bg-primary/10 transition-[width] duration-500" style={{ width: `${progress}%` }} aria-hidden="true" />
          <div className="relative flex items-center justify-between gap-4">
            <div>
              <p className="font-mono text-4xl font-semibold tracking-tight tabular-nums">{display}</p>
              <p className="mt-1 text-xs text-muted-foreground">
                {finished ? (
                  <span className="inline-flex items-center gap-1 text-primary">
                    <Check className="size-3.5" />
                    {t('focusComplete')}
                  </span>
                ) : (
                  `${hours > 0 ? `${hours} ${t('hours')} ` : ''}${minutesInput} ${t('minutes')} ${secondsInput} ${t('seconds')}`
                )}
              </p>
            </div>
            <div className="flex gap-2">
              <Button size="icon" variant="outline" onClick={reset} aria-label={t('reset')}>
                <RotateCcw className="size-4" />
              </Button>
              <Button size="lg" onClick={() => setRunning((value) => !value)}>
                {running ? <Pause data-icon="inline-start" /> : <Play data-icon="inline-start" />}
                {running ? t('pause') : t('start')}
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
