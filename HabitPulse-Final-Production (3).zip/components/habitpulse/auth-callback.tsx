'use client'

import { useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { Loader2, TriangleAlert } from 'lucide-react'
import { buttonVariants } from '@/components/ui/button'
import { useAuth } from '@/hooks/use-auth'
import { safeNextPath } from '@/lib/auth'

/**
 * Landing page for Google OAuth, email confirmation and password-reset links.
 * supabase-js exchanges the ?code= param on init; we just wait for the session.
 */
export function AuthCallback() {
  const router = useRouter()
  const params = useSearchParams()
  const { supabase, ready, session } = useAuth()
  const [error, setError] = useState<string | null>(null)
  const next = safeNextPath(params.get('next'))

  useEffect(() => {
    const hash = new URLSearchParams(window.location.hash.replace(/^#/, ''))
    const urlError = params.get('error_description') ?? hash.get('error_description')
    if (urlError) setError(urlError.replace(/\+/g, ' '))
  }, [params])

  useEffect(() => {
    if (error || !ready) return
    if (!supabase) {
      router.replace('/')
      return
    }
    if (session) {
      router.replace(next)
      return
    }
    // Session may still be settling after the code exchange; give it a moment before failing.
    const timer = window.setTimeout(
      () => setError('We could not complete sign-in. The link may have expired or was opened in a different browser.'),
      4000,
    )
    return () => window.clearTimeout(timer)
  }, [ready, session, supabase, error, next, router])

  return (
    <main className="flex min-h-dvh items-center justify-center px-4">
      <div className="flex max-w-sm flex-col items-center gap-4 text-center">
        {error ? (
          <>
            <span className="flex size-11 items-center justify-center rounded-xl bg-destructive/10 text-destructive">
              <TriangleAlert className="size-5" aria-hidden="true" />
            </span>
            <h1 className="text-lg font-semibold">Sign-in didn&apos;t finish</h1>
            <p role="alert" className="text-sm text-muted-foreground">
              {error}
            </p>
            <Link href="/" className={buttonVariants()}>
              Back to HabitPulse
            </Link>
          </>
        ) : (
          <>
            <Loader2 className="size-6 animate-spin text-primary" aria-hidden="true" />
            <p className="text-sm text-muted-foreground" role="status">
              Signing you in…
            </p>
          </>
        )}
      </div>
    </main>
  )
}
