'use client'

import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'

export type Locale = 'en' | 'ar'

const LOCALE_KEY = 'habitpulse:locale:v1'

type Dictionary = Record<string, string>

const EN: Dictionary = {
  dashboard: 'Dashboard', settings: 'Settings', preferences: 'Preferences', notifications: 'Notifications', account: 'Account',
  appearance: 'Appearance', appearanceDescription: 'Choose how HabitPulse looks on this device.', language: 'Language',
  languageDescription: 'Switch between English and Arabic. Arabic enables a complete right-to-left layout.', english: 'English', arabic: 'العربية',
  backToDashboard: 'Dashboard', manageSettings: 'Manage your account, preferences and reminders.', weeklyMatrix: 'Weekly habit matrix', thisWeek: 'This week', addHabit: 'Add New Habit',
  noHabits: 'No habits yet', noHabitsDescription: 'Start with one small habit you can do every day, then build from there.', habit: 'Habit', streak: 'Streak', week: 'Week', dayStreak: 'day streak', completionRate: 'Completion rate', checkIns: 'check-ins this week', bestStreak: 'Best streak', days: 'days', leadingHabit: 'Leading habit', startStreak: 'Check in today to start a streak', perfectDays: 'Perfect days', everyHabitDone: 'Every habit done',
  focusTimer: 'Focus timer', focusTimerDescription: 'Start a focused session for reading, sport, or deep work.', start: 'Start', pause: 'Pause', reset: 'Reset', focusComplete: 'Focus session complete', minutes: 'min', hours: 'hr', seconds: 'sec', customDuration: 'Custom duration',
  focusReady: 'Ready when you are.', focusRunning: 'Focus in progress', focusFinished: 'Session complete', focusSessions: 'sessions', focusMinutes: 'focused min', timerSound: 'Timer sound', digitalChime: 'Digital Chime', successBell: 'Success Bell', classicAlarm: 'Classic Alarm', gentleGong: 'Gentle Gong', playTestSound: 'Play test sound', chooseDuration: 'Choose duration',
  streakInDanger: 'Your streak is in danger!', streakInDangerDescription: 'You still have habits waiting today. A small win keeps your momentum alive.', protectStreak: 'Protect your streak',
  morning: 'Good morning', afternoon: 'Good afternoon', evening: 'Good evening', allDone: 'Every habit done today. That is a perfect day.', keepGoing: 'Keep the pulse going.', addFirst: 'Add your first habit to start building momentum.',
  weeklyReflection: 'Weekly reflection', reflectionDescription: "Wins, lessons, and next week's focus", unsaved: 'Unsaved', saved: 'Saved', reflectionPlaceholder: 'What went well this week? What will you change?',
  addNewHabit: 'Add new habit', addHabitDescription: 'Small, specific, and daily works best.', habitName: 'Habit name', targetTime: 'Target time', quickPicks: 'Quick picks', cancel: 'Cancel', habitPlaceholder: 'e.g. Stretch for 10 minutes',
  globalTemplates: 'Global templates', globalTemplatesDescription: 'A short set of refined habits to start with.',
  workout: 'High-Energy Workout', deepWork: 'Deep Work / Study', hydration: 'Hydration Goal', reading: 'Reading', mindfulness: 'Mindfulness / Meditation', digitalDetox: 'Digital detox before bed',
  templates: 'Templates', yourData: 'Your data', exportHabits: 'Export habits', exported: 'Exported', light: 'Light', dark: 'Dark', system: 'System',
  dataCloud: 'Your habits are synced to your account. Download a copy any time.', completionsNotes: 'Completions, notes and reflections.',
  dailyReminders: 'Daily reminders', enableReminders: 'Enable reminders', remindersDescription: 'Get a nudge at each habit’s target time. Habits you’ve already checked off stay quiet.', smartNudges: 'Smart streak nudges', smartNudgesDescription: 'Playful reminders help you protect your streak when the day starts slipping.', nudgePreview: 'Preview a smart nudge', nudgePreviewDescription: 'See the gamified streak-protection message without waiting.', nudgePreviewTitle: 'Your 10-day streak is in danger!', nudgePreviewBody: 'One tiny win keeps the flame alive. You’ve got this.',
  browserPermission: 'Browser permission', allowed: 'Allowed', blocked: 'Blocked', notAsked: 'Not asked yet', unsupported: 'Not supported', useInApp: 'Use in-app reminders', sendTest: 'Send test notification', wellnessReminders: 'Wellness & Health Reminders', wellnessRemindersDescription: 'Choose the healthy nudges you want to receive. Each preference is independent.', hydrationReminder: 'Hydration reminders', hydrationReminderDescription: 'Get gentle prompts to pause and drink water throughout the day.', digitalDetoxReminder: 'Digital detox reminders', digitalDetoxReminderDescription: 'A calm reminder to turn off your phone 15 minutes before bedtime.', mindfulnessReminder: 'Mindfulness & stretching nudges', mindfulnessReminderDescription: 'Make space for a short breathing, mindfulness, or stretching break.',
  exportCsv: 'Export as CSV', exportJson: 'Export as JSON', signedOut: 'Signed out', synced: 'Synced with Supabase',
  previousWeek: 'Previous week', nextWeek: 'Next week', sideNotes: 'Side notes for {name} this week', notePlaceholder: 'What helped? What got in the way?', actions: 'Actions', delete: 'Delete', hide: 'Hide', show: 'Show',
}

const AR: Dictionary = {
  dashboard: 'لوحة التحكم', settings: 'الإعدادات', preferences: 'التفضيلات', notifications: 'الإشعارات', account: 'الحساب', appearance: 'المظهر',
  appearanceDescription: 'اختر طريقة ظهور HabitPulse على هذا الجهاز.', language: 'اللغة', languageDescription: 'بدّل بين الإنجليزية والعربية. تفعّل العربية تخطيطاً كاملاً من اليمين إلى اليسار.', english: 'English', arabic: 'العربية',
  backToDashboard: 'لوحة التحكم', manageSettings: 'إدارة حسابك وتفضيلاتك وتذكيراتك.', weeklyMatrix: 'مصفوفة العادات الأسبوعية', thisWeek: 'هذا الأسبوع', addHabit: 'إضافة عادة جديدة', noHabits: 'لا توجد عادات بعد', noHabitsDescription: 'ابدأ بعادة صغيرة يمكنك القيام بها يومياً، ثم تطوّر تدريجياً.', habit: 'العادة', streak: 'الاستمرارية', week: 'الأسبوع', dayStreak: 'يوم متتالٍ', completionRate: 'نسبة الإنجاز', checkIns: 'تسجيلات هذا الأسبوع', bestStreak: 'أفضل استمرارية', days: 'أيام', leadingHabit: 'العادة المتقدمة', startStreak: 'أنجز اليوم لبدء الاستمرارية', perfectDays: 'الأيام المثالية', everyHabitDone: 'تم إنجاز كل العادات',
  focusTimer: 'مؤقت التركيز', focusTimerDescription: 'ابدأ جلسة تركيز للقراءة أو الرياضة أو العمل العميق.', start: 'بدء', pause: 'إيقاف مؤقت', reset: 'إعادة ضبط', focusComplete: 'اكتملت جلسة التركيز', minutes: 'دقيقة', hours: 'س', seconds: 'ث', customDuration: 'مدة مخصصة', focusReady: 'جاهز عندما تكون كذلك.', focusRunning: 'جلسة التركيز جارية', focusFinished: 'اكتملت الجلسة', focusSessions: 'جلسات', focusMinutes: 'دقيقة تركيز', timerSound: 'صوت المؤقت', digitalChime: 'رنين رقمي', successBell: 'جرس النجاح', classicAlarm: 'منبّه كلاسيكي', gentleGong: 'جرس لطيف', playTestSound: 'تشغيل صوت تجريبي', chooseDuration: 'اختر المدة',
  streakInDanger: 'استمراريتك في خطر!', streakInDangerDescription: 'لديك عادات تنتظر الإنجاز اليوم. انتصار صغير يحافظ على زخمك.', protectStreak: 'احمِ استمراريتك', morning: 'صباح الخير', afternoon: 'مساء الخير', evening: 'مساء الخير', allDone: 'أنجزت كل عادات اليوم. هذا يوم مثالي.', keepGoing: 'واصل النبض.', addFirst: 'أضف أول عادة لتبدأ بناء زخمك.',
  weeklyReflection: 'مراجعة الأسبوع', reflectionDescription: 'الإنجازات والدروس وتركيز الأسبوع القادم', unsaved: 'غير محفوظ', saved: 'محفوظ', reflectionPlaceholder: 'ما الذي سار بشكل جيد هذا الأسبوع؟ وما الذي ستغيّره؟', addNewHabit: 'إضافة عادة جديدة', addHabitDescription: 'الأفضل أن تكون صغيرة ومحددة ويومية.', habitName: 'اسم العادة', targetTime: 'الوقت المستهدف', quickPicks: 'اختيارات سريعة', cancel: 'إلغاء', habitPlaceholder: 'مثال: تمارين تمدد لمدة 10 دقائق',
  globalTemplates: 'قوالب عالمية', globalTemplatesDescription: 'مجموعة مختارة وخفيفة من العادات للبدء.', workout: 'تمرين عالي الطاقة', deepWork: 'عمل عميق / دراسة', hydration: 'هدف الترطيب', reading: 'القراءة', mindfulness: 'اليقظة / التأمل', digitalDetox: 'الابتعاد عن الهاتف قبل النوم', templates: 'القوالب', yourData: 'بياناتك', exportHabits: 'تصدير العادات', exported: 'تم التصدير', light: 'فاتح', dark: 'داكن', system: 'النظام', dataCloud: 'تتم مزامنة عاداتك مع حسابك. يمكنك تنزيل نسخة في أي وقت.', completionsNotes: 'الإنجازات والملاحظات والمراجعات.', dailyReminders: 'التذكيرات اليومية', enableReminders: 'تفعيل التذكيرات', remindersDescription: 'احصل على تنبيه عند الوقت المستهدف لكل عادة. العادات المنجزة تبقى هادئة.', smartNudges: 'تنبيهات الاستمرارية الذكية', smartNudgesDescription: 'تذكيرات مرحة تساعدك على حماية استمراريتك عندما يبدأ اليوم بالتعثر.', nudgePreview: 'معاينة تنبيه ذكي', nudgePreviewDescription: 'شاهد رسالة حماية الاستمرارية دون انتظار.', nudgePreviewTitle: 'استمراريتك ذات العشرة أيام في خطر!', nudgePreviewBody: 'إنجاز صغير واحد يبقي الشعلة مشتعلة. أنت قادر على ذلك.', wellnessReminders: 'تذكيرات العافية والصحة', wellnessRemindersDescription: 'اختر التنبيهات الصحية التي تريد تلقيها. كل تفضيل مستقل عن الآخر.', hydrationReminder: 'تذكيرات شرب الماء', hydrationReminderDescription: 'احصل على تذكيرات لطيفة للتوقف وشرب الماء خلال اليوم.', digitalDetoxReminder: 'تذكيرات الابتعاد الرقمي', digitalDetoxReminderDescription: 'تذكير هادئ بإيقاف الهاتف قبل موعد النوم بـ 15 دقيقة.', mindfulnessReminder: 'تنبيهات اليقظة والتمدد', mindfulnessReminderDescription: 'خصص وقتاً لاستراحة قصيرة للتنفس أو اليقظة أو التمدد.', browserPermission: 'إذن المتصفح', allowed: 'مسموح', blocked: 'محظور', notAsked: 'لم يُطلب بعد', unsupported: 'غير مدعوم', useInApp: 'استخدام تذكيرات داخل التطبيق', sendTest: 'إرسال إشعار تجريبي', exportCsv: 'تصدير CSV', exportJson: 'تصدير JSON', signedOut: 'تم تسجيل الخروج', synced: 'تمت المزامنة مع Supabase', previousWeek: 'الأسبوع السابق', nextWeek: 'الأسبوع التالي', sideNotes: 'ملاحظات جانبية لـ {name} هذا الأسبوع', notePlaceholder: 'ما الذي ساعدك؟ وما الذي أعاقك؟', actions: 'إجراءات', delete: 'حذف', hide: 'إخفاء', show: 'إظهار',
}

interface LocaleContextValue { locale: Locale; isArabic: boolean; setLocale: (locale: Locale) => void; t: (key: string, vars?: Record<string, string>) => string; formatDate: (date: Date, options?: Intl.DateTimeFormatOptions) => string; formatTime: (time: string) => string }
const LocaleContext = createContext<LocaleContextValue | null>(null)

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>('en')
  useEffect(() => { const saved = window.localStorage.getItem(LOCALE_KEY) as Locale | null; if (saved === 'ar' || saved === 'en') setLocaleState(saved) }, [])
  useEffect(() => { document.documentElement.lang = locale; document.documentElement.dir = locale === 'ar' ? 'rtl' : 'ltr'; document.documentElement.dataset.locale = locale; try { window.localStorage.setItem(LOCALE_KEY, locale) } catch {} }, [locale])
  const value = useMemo<LocaleContextValue>(() => {
    const dict = locale === 'ar' ? { ...EN, ...AR } : EN
    const t = (key: string, vars?: Record<string, string>) => Object.entries(vars ?? {}).reduce((text, [name, replacement]) => text.replace(`{${name}}`, replacement), dict[key] ?? EN[key] ?? key)
    const formatDate = (date: Date, options?: Intl.DateTimeFormatOptions) => date.toLocaleDateString(locale === 'ar' ? 'ar-SA' : 'en-US', options)
    const formatTime = (time: string) => { if (!time) return ''; const [h, m] = time.split(':').map(Number); const date = new Date(); date.setHours(h, m, 0, 0); return date.toLocaleTimeString(locale === 'ar' ? 'ar-SA' : 'en-US', { hour: 'numeric', minute: '2-digit' }) }
    return { locale, isArabic: locale === 'ar', setLocale: (next) => setLocaleState(next), t, formatDate, formatTime }
  }, [locale])
  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>
}

export function useLocale() { const context = useContext(LocaleContext); if (!context) throw new Error('useLocale must be used within LocaleProvider'); return context }
