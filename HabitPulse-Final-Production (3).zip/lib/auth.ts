import type { SupabaseClient, User } from '@supabase/supabase-js'

/** Only allow same-site relative paths so ?next= can't be used as an open redirect. */
export function safeNextPath(value: string | null | undefined, fallback = '/'): string {
  if (!value || !value.startsWith('/') || value.startsWith('//') || value.includes('\\')) return fallback
  return value
}

export function authRedirectUrl(next = '/'): string {
  return `${window.location.origin}/auth/callback?next=${encodeURIComponent(safeNextPath(next))}`
}

/**
 * Starts Google OAuth. Google refuses to render inside iframes (e.g. preview panes),
 * so in that case the flow opens in a new tab instead of navigating the frame.
 */
export async function signInWithGoogle(supabase: SupabaseClient, next = '/'): Promise<string | null> {
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: authRedirectUrl(next), skipBrowserRedirect: true },
  })
  if (error) return error.message
  if (!data.url) return 'Could not start Google sign-in.'
  if (window.self !== window.top) window.open(data.url, '_blank', 'noopener')
  else window.location.assign(data.url)
  return null
}

export function getDisplayName(user: User | null): string {
  const meta = user?.user_metadata ?? {}
  return (
    (meta.full_name as string | undefined)?.trim() ||
    (meta.name as string | undefined)?.trim() ||
    user?.email?.split('@')[0] ||
    'Guest'
  )
}

export function getAvatarUrl(user: User | null): string | null {
  const meta = user?.user_metadata ?? {}
  return ((meta.avatar_url ?? meta.picture) as string | undefined) || null
}

/** Sign-in methods linked to the account, e.g. ['email', 'google']. */
export function getProviders(user: User | null): string[] {
  const fromIdentities = user?.identities?.map((i) => i.provider) ?? []
  const fromMeta = (user?.app_metadata?.providers as string[] | undefined) ?? []
  return [...new Set([...fromIdentities, ...fromMeta])]
}
