export interface Habit {
  id: string
  name: string
  targetTime: string
  createdAt: string
}

/** habitId -> ISO date (YYYY-MM-DD) -> completed */
export type Completions = Record<string, Record<string, true>>

/** week key (ISO date of Saturday) -> habitId -> note text */
export type HabitNotes = Record<string, Record<string, string>>

/** week key -> free-form weekly reflection */
export type WeeklyReflections = Record<string, string>

export interface HabitState {
  habits: Habit[]
  completions: Completions
  notes: HabitNotes
  reflections: WeeklyReflections
}

export interface WeekDay {
  date: Date
  iso: string
  shortLabel: string
  dayNumber: number
  isToday: boolean
  isFuture: boolean
}

export const FREE_HABIT_LIMIT = 10
export const PRO_PRICE_MONTHLY = 3.99

const SATURDAY = 6

export function toISODate(date: Date): string {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

export function startOfDay(date: Date): Date {
  const copy = new Date(date)
  copy.setHours(0, 0, 0, 0)
  return copy
}

export function addDays(date: Date, amount: number): Date {
  const copy = new Date(date)
  copy.setDate(copy.getDate() + amount)
  return copy
}

/** Weeks run Saturday → Friday. */
export function startOfWeek(date: Date): Date {
  const day = startOfDay(date)
  const diff = (day.getDay() - SATURDAY + 7) % 7
  return addDays(day, -diff)
}

export function getWeekDays(weekStart: Date, today: Date): WeekDay[] {
  const todayIso = toISODate(today)
  const todayStart = startOfDay(today).getTime()

  return Array.from({ length: 7 }, (_, index) => {
    const date = addDays(weekStart, index)
    return {
      date,
      iso: toISODate(date),
      shortLabel: date.toLocaleDateString('en-US', { weekday: 'short' }),
      dayNumber: date.getDate(),
      isToday: toISODate(date) === todayIso,
      isFuture: date.getTime() > todayStart,
    }
  })
}

/**
 * A day counts toward completion % when it is today or in the past. A future day
 * the user has already checked also counts, so a pre-checked circle is never
 * ignored (and the rate can never exceed 100%).
 */
export function isTrackableDay(day: WeekDay, anyCompleted: boolean): boolean {
  return !day.isFuture || anyCompleted
}

/**
 * Consecutive completed days ending today. If today isn't checked yet,
 * the streak stays alive as long as yesterday was completed.
 */
export function getStreak(
  habitCompletions: Record<string, true> | undefined,
  today: Date,
): number {
  if (!habitCompletions) return 0

  let cursor = startOfDay(today)
  if (!habitCompletions[toISODate(cursor)]) {
    cursor = addDays(cursor, -1)
  }

  let streak = 0
  while (habitCompletions[toISODate(cursor)]) {
    streak += 1
    cursor = addDays(cursor, -1)
  }
  return streak
}

/** Completion % for each of the last `count` weeks, oldest first. */
export function getWeeklyTrend(state: HabitState, today: Date, count: number) {
  const currentStart = startOfWeek(today)
  return Array.from({ length: count }, (_, i) => {
    const weekStart = addDays(currentStart, -(count - 1 - i) * 7)
    const days = getWeekDays(weekStart, today).filter((d) =>
      isTrackableDay(
        d,
        state.habits.some((h) => state.completions[h.id]?.[d.iso]),
      ),
    )
    const possible = days.length * state.habits.length
    const done = state.habits.reduce(
      (sum, h) => sum + days.filter((d) => state.completions[h.id]?.[d.iso]).length,
      0,
    )
    return {
      weekStart,
      label: weekStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      rate: possible === 0 ? 0 : Math.round((done / possible) * 100),
    }
  })
}

/** Longest run of consecutive completed days ever recorded. */
export function getBestStreak(
  habitCompletions: Record<string, true> | undefined,
  today: Date = new Date(),
): number {
  if (!habitCompletions) return 0
  const todayIso = toISODate(today)
  const dates = Object.keys(habitCompletions)
    .filter((iso) => iso <= todayIso)
    .sort()
  let best = 0
  let run = 0
  let previous: Date | null = null
  for (const iso of dates) {
    const [y, m, d] = iso.split('-').map(Number)
    const current = new Date(y, m - 1, d)
    run = previous && toISODate(addDays(previous, 1)) === iso ? run + 1 : 1
    best = Math.max(best, run)
    previous = current
  }
  return best
}

export interface DailyPoint {
  iso: string
  label: string
  done: number
  total: number
  rate: number
  rolling: number
}

/**
 * Daily completion % for the last `days` days (oldest first), plus a
 * trailing 7-day rolling average to smooth day-to-day noise.
 */
export function getDailySeries(
  state: HabitState,
  today: Date,
  days: number,
  habitId: string | null = null,
): DailyPoint[] {
  const habits = habitId ? state.habits.filter((h) => h.id === habitId) : state.habits
  const end = startOfDay(today)
  const raw = Array.from({ length: days + 6 }, (_, i) => {
    const date = addDays(end, -(days + 5 - i))
    const iso = toISODate(date)
    const done = habits.filter((h) => state.completions[h.id]?.[iso]).length
    return { date, iso, done, total: habits.length }
  })

  return raw.slice(6).map((point, i) => {
    const window = raw.slice(i, i + 7)
    const wDone = window.reduce((s, p) => s + p.done, 0)
    const wTotal = window.reduce((s, p) => s + p.total, 0)
    return {
      iso: point.iso,
      label: point.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      done: point.done,
      total: point.total,
      rate: point.total === 0 ? 0 : Math.round((point.done / point.total) * 100),
      rolling: wTotal === 0 ? 0 : Math.round((wDone / wTotal) * 100),
    }
  })
}

export function formatTargetTime(time: string): string {
  if (!time) return ''
  const [h, m] = time.split(':').map(Number)
  const date = new Date()
  date.setHours(h, m, 0, 0)
  return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
}

export function createId(): string {
  return typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`
}

/* ---------- Pure state transitions used by the cloud store ---------- */

export function withHabit(state: HabitState, habit: Habit): HabitState {
  return { ...state, habits: [...state.habits, habit] }
}

export function withoutHabit(state: HabitState, habitId: string): HabitState {
  const { [habitId]: _removed, ...completions } = state.completions
  return { ...state, habits: state.habits.filter((h) => h.id !== habitId), completions }
}

export function withNote(
  state: HabitState,
  weekKey: string,
  habitId: string,
  text: string,
): HabitState {
  return {
    ...state,
    notes: { ...state.notes, [weekKey]: { ...(state.notes[weekKey] ?? {}), [habitId]: text } },
  }
}

export function withReflection(state: HabitState, weekKey: string, text: string): HabitState {
  return { ...state, reflections: { ...state.reflections, [weekKey]: text } }
}

