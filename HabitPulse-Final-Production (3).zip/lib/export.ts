import { getBestStreak, getStreak, type HabitState } from '@/lib/habits'

export type ExportFormat = 'csv' | 'json'

function csvCell(value: string | number | boolean): string {
  const text = String(value)
  // Prefix formula-like values so spreadsheets don't execute them (CSV injection).
  const safe = /^[=+\-@\t\r]/.test(text) ? `'${text}` : text
  return /[",\n\r]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe
}

export function buildCsv(state: HabitState): string {
  const header = ['habit_id', 'habit_name', 'target_time', 'date', 'completed']
  const lines = [header.join(',')]
  for (const habit of state.habits) {
    const dates = Object.keys(state.completions[habit.id] ?? {}).sort()
    for (const date of dates) {
      lines.push([habit.id, habit.name, habit.targetTime, date, true].map(csvCell).join(','))
    }
  }
  return lines.join('\n')
}

export function buildJson(state: HabitState, today: Date): string {
  return JSON.stringify(
    {
      app: 'HabitPulse',
      version: 1,
      exportedAt: new Date().toISOString(),
      habits: state.habits.map((habit) => ({
        ...habit,
        currentStreak: getStreak(state.completions[habit.id], today),
        bestStreak: getBestStreak(state.completions[habit.id], today),
        completedDates: Object.keys(state.completions[habit.id] ?? {}).sort(),
      })),
      notes: state.notes,
      reflections: state.reflections,
    },
    null,
    2,
  )
}

export function downloadExport(state: HabitState, format: ExportFormat, today = new Date()) {
  const content = format === 'csv' ? buildCsv(state) : buildJson(state, today)
  const blob = new Blob([content], {
    type: format === 'csv' ? 'text/csv;charset=utf-8' : 'application/json',
  })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  const stamp = new Date().toISOString().slice(0, 10)
  link.href = url
  link.download = `habitpulse-${stamp}.${format}`
  document.body.appendChild(link)
  link.click()
  link.remove()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
