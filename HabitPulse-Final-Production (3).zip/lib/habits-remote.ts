import type { SupabaseClient } from '@supabase/supabase-js'
import type { Completions, Habit, HabitNotes, HabitState, WeeklyReflections } from '@/lib/habits'

export interface RemoteState extends HabitState {
  isPro: boolean
}

const PAGE_SIZE = 1000

/** Supabase caps a select at 1000 rows by default, so page through every log. */
async function fetchAllLogs(sb: SupabaseClient, userId: string) {
  const rows: { habit_id: string; log_date: string }[] = []
  for (let from = 0; ; from += PAGE_SIZE) {
    const { data, error } = await sb
      .from('habit_logs')
      .select('habit_id, log_date')
      .eq('user_id', userId)
      .order('log_date', { ascending: true })
      .order('habit_id', { ascending: true })
      .range(from, from + PAGE_SIZE - 1)
    if (error) return { data: null, error }
    rows.push(...(data ?? []))
    if (!data || data.length < PAGE_SIZE) return { data: rows, error: null }
  }
}

export async function fetchRemoteState(sb: SupabaseClient, userId: string): Promise<RemoteState> {
  const [habitsRes, logsRes, reflectionsRes, profileRes] = await Promise.all([
    sb
      .from('habits')
      .select('id, name, target_time, created_at')
      .eq('user_id', userId)
      .eq('archived', false)
      .order('created_at', { ascending: true }),
    fetchAllLogs(sb, userId),
    sb.from('weekly_reflections').select('habit_id, week_start, content').eq('user_id', userId),
    sb.from('profiles').select('is_pro').eq('id', userId).maybeSingle(),
  ])

  const error = habitsRes.error ?? logsRes.error ?? reflectionsRes.error ?? profileRes.error
  if (error) throw error

  const habits: Habit[] = (habitsRes.data ?? []).map((row) => ({
    id: row.id,
    name: row.name,
    targetTime: row.target_time ? String(row.target_time).slice(0, 5) : '',
    createdAt: row.created_at,
  }))

  const completions: Completions = {}
  for (const log of logsRes.data ?? []) {
    ;(completions[log.habit_id] ??= {})[log.log_date] = true
  }

  const notes: HabitNotes = {}
  const reflections: WeeklyReflections = {}
  for (const row of reflectionsRes.data ?? []) {
    if (row.habit_id) (notes[row.week_start] ??= {})[row.habit_id] = row.content
    else reflections[row.week_start] = row.content
  }

  return { habits, completions, notes, reflections, isPro: Boolean(profileRes.data?.is_pro) }
}

export async function insertHabit(sb: SupabaseClient, userId: string, habit: Habit) {
  const { error } = await sb.from('habits').insert({
    id: habit.id,
    user_id: userId,
    name: habit.name,
    target_time: habit.targetTime || null,
    created_at: habit.createdAt,
  })
  if (error) throw error
}

export async function deleteHabit(sb: SupabaseClient, userId: string, habitId: string) {
  const { error } = await sb.from('habits').delete().eq('id', habitId).eq('user_id', userId)
  if (error) throw error
}

export async function setHabitLog(
  sb: SupabaseClient,
  userId: string,
  habitId: string,
  isoDate: string,
  done: boolean,
) {
  const { error } = done
    ? await sb
        .from('habit_logs')
        .upsert({ user_id: userId, habit_id: habitId, log_date: isoDate }, { onConflict: 'habit_id,log_date' })
    : await sb
        .from('habit_logs')
        .delete()
        .eq('user_id', userId)
        .eq('habit_id', habitId)
        .eq('log_date', isoDate)
  if (error) throw error
}

export async function saveReflection(
  sb: SupabaseClient,
  userId: string,
  weekStart: string,
  habitId: string | null,
  content: string,
) {
  const { error } = await sb.from('weekly_reflections').upsert(
    {
      user_id: userId,
      habit_id: habitId,
      week_start: weekStart,
      content,
      updated_at: new Date().toISOString(),
    },
    { onConflict: 'user_id,habit_id,week_start' },
  )
  if (error) throw error
}
